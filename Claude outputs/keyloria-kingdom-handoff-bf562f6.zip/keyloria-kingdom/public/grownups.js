/* One Grown-ups hub (behind one quick check per visit): progress report, parent settings / Focus mode,
   teacher dashboard, players, devices and reset. Kid Settings keeps only kid things. Home buttons put learning first. */
(function(){
const ICO=PXG(["..oooo..",".oPPPPo.",".oPPPPo.","..oooo..",".oTTTTo.","oTTTTTTo","oTTTTTTo","oooooooo"],{o:'#2a1d3e',P:'#f2cc8c',T:'#b8a0f0'}).toDataURL();
const CUP=PXG(['oooooooooooo','oYYYYYYYYYYo','oYoYYYYYYoYo','oYoYYYYYYoYo','.ooYYYYYYoo.','..oYYYYYYo..','...oYYYYo...','....oYYo....','...oooooo...','..oYYYYYYo..','..oooooooo..'],{o:'#2a1d3e',Y:'#f0c860'}).toDataURL();window.KK_CUP=CUP;
const CHART=PXG(['............','.........oo.','.........oGo','......oo.oGo','......oGooGo','...oo.oGooGo','...oGooGooGo','oo.oGooGooGo','oGooGooGooGo','oGooGooGooGo','oooooooooooo'],{o:'#2a1d3e',G:'#3a8a3a'}).toDataURL();
ACT.myReport=()=>{window.__repId=null;closeModal();show('parents')};
let GATE=0;
const openHub=()=>{window.__gu=1;window.__clsOk=1;window.__guMode='';
 const card=(act,t,d,c)=>`<button class="guitem ${c}" data-act="${act}"><b>${t}</b><small>${d}</small></button>`;
 modal(`<h2>TEACHERS</h2><p class="muted" style="margin:0 0 10px">Settings and tools for parents and teachers.</p><div class="gugrid">
 ${card('guReport','Progress report','Stars, accuracy and progress in Typing, Math and Spelling for every player','c1')}
 ${card('guParent','Focus mode','Turn the arcade, outfits and other extras on or off','c2')}
 ${card('guTeach','Teacher dashboard','Make a class, assign lessons, watch progress, class races','c3')}
 ${card('guPlayers','Players','Add, switch or delete players on this device','c4')}
 ${card('guDevices','Family code and reset','Play on more than one device with a family code, or start over from zero','c5')}
 </div><p class="gusupport">Keyloria is free with no ads. Enjoying it? <a href="https://ko-fi.com/keyloria" target="_blank" rel="noopener">Support Keyloria on Ko-fi</a></p><div class="rbtns"><button class="btn" data-act="close">DONE</button></div>`);const mb=document.getElementById('mbox');if(mb)mb.classList.add('guwide');try{fitModal()}catch(e){}};
ACT.grownups=()=>{if(window.__gu)return openHub();const a=6+Math.floor(Math.random()*4),b=3+Math.floor(Math.random()*7);GATE=a*b;
 modal(`<h2>TEACHERS AND PARENTS</h2><p class="muted" style="margin:0 0 8px">Quick check before you go in.</p><div class="pgatebox"><p class="pgq">What is ${a} × ${b}?</p><input id="gugate" class="pgin" inputmode="numeric" autocomplete="off" maxlength="10" aria-label="Answer"></div>
 <div class="rbtns"><button class="btn" data-act="guCheck">OK</button><button class="btn alt" data-act="close">BACK</button></div>`);setTimeout(()=>document.getElementById('gugate')?.focus(),50)};
/* master code: typing it into the grown-up check unlocks everything for this player */
function masterUnlock(){try{const NS=typeof NST!=='undefined'?NST:8;
 for(let i=0;i<LESSONS.length;i++)for(let s=0;s<NS;s++){const k=sk(i,s);if(!(S.best[k]>=1))S.best[k]=1}
 S.arc=S.arc||{};S.arc.high=S.arc.high||{};['meteor','glitch','race','bubble','dig','keeper','bridge'].forEach(g=>{if(S.arc.high[g]!=='insanity')S.arc.high[g]='beast'});
 S.daily=S.daily||{day:'',secs:0,streak:0,met:'',lastT:S.time||0};S.daily.best=Math.max(S.daily.best||0,60);
 S.owned=S.owned||[];Object.keys(ACC).forEach(id=>{if(!S.owned.includes(id))S.owned.push(id)});
 const top=Math.max(1,...Object.values(ACC).map(a=>a.lvl||0));if(S.xp<needXP(top))S.xp=needXP(top);
 S.infGems=1;S.gems=99999;S.codeOn=true;S.cards=S.cards||{};for(let i=0;i<LESSONS.length;i++)for(let f=0;f<3;f++){const k=i+'-'+f;S.cards[k]=Object.assign(S.cards[k]||{},{holo:true})}S.rareOwn={drakko:1,kitsu:1,nyx:1,buzz:1};S.rareSeen={drakko:1,kitsu:1,nyx:1,buzz:1};S.spell=S.spell||{};S.spell.beeFlawless=1;S.placed=true;S.camp=true;
 S.story=S.story||{};S.story.shard=S.story.shard||{};for(let w=1;w<=12;w++)S.story.shard[w]=1;
 save();toast('Master code accepted: everything is unlocked!')}catch(e){console.warn(e);toast('Could not unlock everything')}}
window.masterUnlock=masterUnlock;
/* secret codes typed into the grown-up math box. Add new ones with KK_CODES.word=()=>{...}; return true if the code opened its own screen */
window.KK_CODES=window.KK_CODES||{};KK_CODES.moxforma=()=>{masterUnlock();try{renderHome()}catch(e){}return false};
window.kkCode=id=>{const v=((document.getElementById(id)||{}).value||'').trim().toLowerCase(),f=v&&Object.prototype.hasOwnProperty.call(KK_CODES,v)&&KK_CODES[v];if(!f)return null;return f()?'own':'done'};
ACT.guCheck=()=>{const c=kkCode('gugate');if(c==='own')return;if(c==='done')return openHub();const v=+(document.getElementById('gugate')?.value||0);if(v!==GATE){try{sfx.bad()}catch(e){}toast('Not quite. Ask a grown-up!');return ACT.grownups()}openHub()};
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target&&e.target.id==='gugate'){e.preventDefault();e.stopPropagation();ACT.guCheck()}},true);
ACT.insta=()=>{window.open('https://www.instagram.com/keyloria.kingdom','_blank','noopener')};
ACT.kofi=()=>{window.open('https://ko-fi.com/keyloria','_blank','noopener')};
ACT.howto=()=>{window.open('/','_blank','noopener')};
ACT.guReport=()=>{window.__repId=null;closeModal();show('parents')};
/* progress report covers every player on this device: an overview table + a tab per player */
ACT.guRep=d=>{window.__repId=d.id;renderParents();scrollTo(0,0)};
const _rp=renderParents;renderParents=function(){try{save()}catch(e){}
 const list=(typeof PROF!=='undefined'&&PROF.list)||[],cur=typeof PROF!=='undefined'?PROF.cur:null,id=window.__repId&&list.includes(window.__repId)?window.__repId:cur;
 const get=k=>k===cur?S:Object.assign(structuredClone(DEF),peek(k));
 const keep=S;let r;if(id!==cur)S=get(id);try{r=_rp.apply(this,arguments)}finally{S=keep}
 try{const box=document.getElementById('s-parents'),tb=box&&box.querySelector('.topbar');if(!tb||list.length<1)return r;
  const avg=(a,f)=>a.length?Math.round(a.reduce((s,x)=>s+f(x),0)/a.length):0;
  const rows=list.map(k=>{const d=get(k),last=(d.hist||[]).slice(-10),done=Object.values(d.best||{}).filter(b=>b>=1).length;
   return `<tr class="${k===id?'on':''}"><td><b>${esc(d.name||'Player')}</b></td><td>${Math.round((d.time||0)/60)} min</td><td>${done}/${LESSONS.length*8}</td><td>${last.length?avg(last,x=>x.a)+'%':'–'}</td><td>${last.length?avg(last,x=>x.w):'–'}</td></tr>`}).join('');
  try{const d=get(id),O=window.ORDER||LESSONS.map((_,k)=>k),SN={typing:'Typing',math:'Math',spell:'Spelling'};
   const sum=(best)=>{best=best||{};let stars=0,done=0,nx=null;O.forEach(i=>{let n=0;for(let q=0;q<NST;q++){const b=best[i+'-'+q]||0;if(b>=1)n++;stars+=Math.min(3,b)}if(n>=NST)done++;else if(nx==null)nx=i});return{stars,done,w:nx==null?null:worldOf(nx),any:Object.keys(best).length>0}};
   const rows2=['typing','math','spell'].map(sid=>{const sv=sid==='typing'?d.best:(d.streams&&d.streams[sid]&&d.streams[sid].best),q=sum(sv),wn=q.w==null?(q.done?'All worlds done':'–'):(q.any?`World ${q.w}: ${(WORLDS[q.w-1]||{}).name||''}`:'Not started');
    const last=(d.hist||[]).slice(-10),wpm=sid==='typing'&&last.length?Math.round(last.reduce((a,x)=>a+x.w,0)/last.length)+' WPM':'–';
    return `<tr data-stream="${sid}"><td><b>${SN[sid]}</b></td><td>${q.stars}</td><td>${q.done} of ${O.length}</td><td>${esc(wn)}</td><td>${wpm}</td></tr>`}).join('');
   const host=box.querySelector('.gradebox')||box.querySelector('.topbar');
   host.insertAdjacentHTML('afterend',`<div class="panel pbox gustreams" style="margin-bottom:12px"><h3>Progress by subject</h3><table class="guall"><tr><th>Subject</th><th>Stars</th><th>Lessons done</th><th>Current world</th><th>Speed</th></tr>${rows2}</table><p class="muted" style="margin:6px 0 0;font-size:15px">Typing speed (WPM) comes from typing rounds only. Math and Spelling count stars and lessons, never speed.</p></div>`)}catch(e){console.warn(e)}
  const nm=esc(get(id).name||'Player');
  tb.insertAdjacentHTML('afterend',`<div class="panel pbox"><h3>All players</h3><table class="guall"><tr><th>Player</th><th>Time</th><th>Levels</th><th>Accuracy</th><th>WPM</th></tr>${rows}</table>
   ${list.length>1?`<div class="gutabs">${list.map(k=>`<button class="btn sm ${k===id?'on':'alt'}" data-act="guRep" data-id="${k}">${esc(get(k).name||'Player')}</button>`).join('')}</div>`:''}</div><h2 class="gurepname">Details for ${nm}</h2>`);
 }catch(e){console.warn(e)}return r};
ACT.guParent=()=>{window.parPanel&&parPanel()};
ACT.guTeach=()=>{window.teachList&&teachList()};
ACT.guPlayers=()=>{window.__guMode='players';ACT.players()};
ACT.guDevices=()=>{window.__guMode='devices';ACT.settings()};
/* the parent-settings gate inside Settings now opens the hub's parent settings directly once checked */
const _pg=ACT.parGate;ACT.parGate=function(){if(window.__gu)return parPanel();return _pg.apply(this,arguments)};


/* ---- Teacher password: protects the teacher dashboard (and class controls) on a shared device ---- */
const TPW='kl-teach-pw';
const tpw=()=>{try{return JSON.parse(localStorage.getItem(TPW)||'null')}catch(e){return null}};
const hash=async t=>{const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('keyloria:'+t));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')};

/* With a teacher password on, the class keys are stored encrypted (AES-GCM, key from the password via PBKDF2),
   so copying this browser's storage is useless without the password or the recovery code. */
const TEACHK='kl-teach';window.__tkPlain=window.__tkPlain||{};
const b64=u=>btoa(String.fromCharCode(...new Uint8Array(u))),ub64=x=>Uint8Array.from(atob(x),c=>c.charCodeAt(0));
async function kdf(pw,salt){const base=await crypto.subtle.importKey('raw',new TextEncoder().encode(pw),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:150000,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,['wrapKey','unwrapKey'])}
async function wrapK(K,pw,salt){const w=await kdf(pw,salt),iv=crypto.getRandomValues(new Uint8Array(12));return b64(iv)+'.'+b64(await crypto.subtle.wrapKey('raw',K,w,{name:'AES-GCM',iv}))}
async function unwrapK(x,pw,salt){const [iv,ct]=x.split('.');return crypto.subtle.unwrapKey('raw',ub64(ct),await kdf(pw,salt),{name:'AES-GCM',iv:ub64(iv)},{name:'AES-GCM'},true,['encrypt','decrypt'])}
async function encTk(K,t){const iv=crypto.getRandomValues(new Uint8Array(12));return b64(iv)+'.'+b64(await crypto.subtle.encrypt({name:'AES-GCM',iv},K,new TextEncoder().encode(t)))}
async function decTk(K,x){const [iv,ct]=x.split('.');return new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:ub64(iv)},K,ub64(ct)))}
const rawTeach=()=>{try{return JSON.parse(localStorage.getItem(TEACHK)||'{}')}catch(e){return{}}};
const putTeach=t=>{try{localStorage.setItem(TEACHK,JSON.stringify(t))}catch(e){}};
window.kkTkFill=t=>{for(const c in t)if(t[c]&&!t[c].tk&&window.__tkPlain[c])t[c].tk=window.__tkPlain[c]};
async function sealAll(){const p=tpw(),K=window.__tkK;if(!p||!p.wp||!K)return;const t=rawTeach();let ch=false;
 for(const c in t){const e=t[c];if(e&&e.tk){window.__tkPlain[c]=e.tk;e.etk=await encTk(K,e.tk);delete e.tk;ch=true}}if(ch)putTeach(t)}
window.kkTkSeal=()=>{sealAll().catch(e=>console.warn(e))};
async function openAll(K){const t=rawTeach();for(const c in t){const e=t[c];if(e&&e.etk)try{window.__tkPlain[c]=await decTk(K,e.etk)}catch(x){}else if(e&&e.tk)window.__tkPlain[c]=e.tk}}
function unsealAll(){const t=rawTeach();for(const c in t){const e=t[c];if(e&&e.etk&&window.__tkPlain[c]){e.tk=window.__tkPlain[c];delete e.etk}}putTeach(t)}
const needPw=()=>!!tpw()&&!window.__tpwOk;
let PW_NEXT=null;
const pwAsk=next=>{PW_NEXT=next;modal(`<h2>TEACHER PASSWORD</h2><p class="muted" style="margin:0 0 10px">The teacher dashboard on this device is locked.</p>
 <div class="pgatebox"><input id="tpwin" class="pgin" type="password" autocomplete="off" aria-label="Teacher password" style="width:260px;letter-spacing:.1em"></div>
 <div class="rbtns"><button class="btn" data-act="tpwCheck">UNLOCK</button><button class="btn alt" data-act="grownups">BACK</button></div>
 <p class="muted" style="margin:10px 0 0"><button class="linkbtn" data-act="tpwForgot">Forgot the password?</button></p>`);setTimeout(()=>document.getElementById('tpwin')?.focus(),50)};
ACT.tpwCheck=async()=>{const p=tpw(),v=document.getElementById('tpwin')?.value||'';if(p&&await hash(v)===p.h){if(p.wp)try{window.__tkK=await unwrapK(p.wp,v,ub64(p.s));await openAll(window.__tkK)}catch(e){console.warn(e)}window.__tpwOk=1;const n=PW_NEXT;PW_NEXT=null;return n?n():window.teachList()}
 try{sfx.bad()}catch(e){}toast('Wrong password');const i=document.getElementById('tpwin');if(i){i.value='';i.focus()}};
ACT.tpwForgot=()=>modal(`<h2>FORGOT PASSWORD</h2><p class="muted" style="margin:0 0 10px">Type the recovery code you saved when you set the password.</p>
 <div class="pgatebox"><input id="tpwrec" class="pgin" autocomplete="off" maxlength="9" aria-label="Recovery code" style="width:260px;text-transform:uppercase"></div>
 <div class="rbtns"><button class="btn" data-act="tpwRecover">REMOVE PASSWORD</button><button class="btn alt" data-act="grownups">BACK</button></div>`);
ACT.tpwRecover=async()=>{const p=tpw(),v=(document.getElementById('tpwrec')?.value||'').trim().toUpperCase().replace(/[^A-Z0-9]/g,'');
 if(p&&await hash('rec:'+v)===p.r){if(p.wr)try{await openAll(await unwrapK(p.wr,v,ub64(p.s)));unsealAll()}catch(e){console.warn(e)}window.__tkK=null;try{localStorage.removeItem(TPW)}catch(e){}window.__tpwOk=1;toast('Password removed');return window.teachList()}toast('That code does not match')};
ACT.tpwSet=()=>{const has=!!tpw();modal(`<h2>${has?'CHANGE':'SET A'} TEACHER PASSWORD</h2><p class="muted" style="margin:0 0 10px">Locks the teacher dashboard and class controls on this device, so students can't change them even if they pass the maths question.</p><p class="muted" style="margin:0 0 10px;font-size:.85em">Your class keys are also locked with it, so copying this browser's data won't open your dashboard. Keep the recovery code safe.</p>
 <div class="pgatebox" style="display:grid;gap:10px;justify-items:center"><input id="tpw1" class="pgin" type="password" autocomplete="new-password" placeholder="Password" aria-label="New password" style="width:280px"><input id="tpw2" class="pgin" type="password" autocomplete="new-password" placeholder="Type it again" aria-label="Repeat password" style="width:280px"></div>
 <div class="rbtns"><button class="btn" data-act="tpwSave">SAVE</button>${has?'<button class="btn alt" data-act="tpwOff">TURN OFF</button>':''}<button class="btn alt" data-act="tpwBack">BACK</button></div>`);setTimeout(()=>document.getElementById('tpw1')?.focus(),50)};
ACT.tpwBack=()=>ACT.clsDash?ACT.clsDash({}):window.teachList();
ACT.tpwOff=()=>{unsealAll();window.__tkK=null;try{localStorage.removeItem(TPW)}catch(e){}toast('Password turned off');ACT.tpwBack()};
ACT.tpwSave=async()=>{const a=document.getElementById('tpw1')?.value||'',b=document.getElementById('tpw2')?.value||'';
 if(a.length<4)return toast('Use at least 4 characters');if(a!==b)return toast('The two passwords do not match');
 const AL='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',rnd=crypto.getRandomValues(new Uint8Array(8)),rec=[...rnd].map(x=>AL[x%AL.length]).join('');
 try{const t=rawTeach();for(const c in t)if(t[c]&&t[c].tk)window.__tkPlain[c]=t[c].tk;unsealAll();const K=await crypto.subtle.generateKey({name:'AES-GCM',length:256},true,['encrypt','decrypt']),salt=crypto.getRandomValues(new Uint8Array(16));
 localStorage.setItem(TPW,JSON.stringify({h:await hash(a),r:await hash('rec:'+rec),s:b64(salt),wp:await wrapK(K,a,salt),wr:await wrapK(K,rec,salt)}));window.__tkK=K;await sealAll()}catch(e){console.warn(e);return toast('Could not save')}window.__tpwOk=1;
 modal(`<h2>PASSWORD SAVED</h2><p class="muted" style="margin:0 0 8px">Write down this recovery code. It is the only way to remove the password if you forget it.</p><div class="cl-big">${rec.slice(0,4)}-${rec.slice(4)}</div>
 <div class="rbtns"><button class="btn" data-act="tpwBack">I WROTE IT DOWN</button></div>`)};
const _gt=ACT.guTeach;ACT.guTeach=function(){if(needPw())return pwAsk(()=>_gt());return _gt.apply(this,arguments)};
const _ct=ACT.clsTeach;if(_ct)ACT.clsTeach=function(){if(needPw())return pwAsk(()=>_ct());return _ct.apply(this,arguments)};
const _cd=ACT.clsDash;ACT.clsDash=function(d){if(needPw()&&!(d&&d.quiet))return pwAsk(()=>ACT.clsDash(d));const r=_cd.apply(this,arguments);
return r};
document.addEventListener('keydown',e=>{const id=e.target&&e.target.id;if(e.key!=='Enter')return;const m={tpwin:'tpwCheck',tpwrec:'tpwRecover',tpw2:'tpwSave'}[id];if(m){e.preventDefault();e.stopPropagation();ACT[m]()}},true);

/* ---- Keylori Collection: holo / gold / diamond counts get their icons ---- */
const TI={holo:PXG(['..ooo..','.oRYGo.','oRYGBPo','oYGBPRo','oGBPRYo','.oPRYo.','..ooo..'],{o:'#2a1d3e',R:'#ff8a9a',Y:'#f0e070',G:'#7fe8a0',B:'#7fc8f0',P:'#c8a0f0'}).toDataURL(),
 gold:PXG(['..ooo..','.oYYYo.','oYWYYDo','oYYYYDo','oYYYDDo','.oDDDo.','..ooo..'],{o:'#2a1d3e',Y:'#f0c860',W:'#fff6c0',D:'#c8981e'}).toDataURL(),
 diamond:PXG(['..ooooo..','.oWCCCBo.','oWCCCCCBo','ooooooooo','.oCCCCBo.','..oCCBo..','...oBo...','....o....'],{o:'#2a1d3e',W:'#ffffff',C:'#bfe2f6',B:'#7fb8e0'}).toDataURL()};
const _rb=renderBinder;renderBinder=function(){const r=_rb.apply(this,arguments);try{const sp=document.querySelector('#s-binder .topbar>span.muted');if(sp&&!sp.querySelector('.tico')){
 const C=Object.values(S.cards),n=C.length,holo=C.filter(x=>x.holo).length,gold=C.filter(x=>x.tier==='gold').length,dia=C.filter(x=>x.tier==='diamond').length;
 const it=(k,v,l)=>`<span class="tcount" title="${l}"><img class="tico" src="${TI[k]}" alt="">${v} ${l}</span>`;
 sp.innerHTML=`${n}/${typeof TOTAL!=='undefined'?TOTAL:''} ${it('holo',holo,'holo')}${it('gold',gold,'gold')}${it('diamond',dia,'diamond')}`;sp.classList.add('tcounts')}}catch(e){console.warn(e)}return r};

/* ---- Keylori roaming the home screen: off by default, no header switch, secret invisible toggle right of Settings ---- */
try{if(S.set&&S.set.roamOn===undefined){S.set.roamOn=false;S.set.hideRoam=true;save()}}catch(e){}
ACT.roamSecret=()=>{S.set.roamOn=!S.set.roamOn;S.set.hideRoam=!S.set.roamOn;save();try{sfx.click&&sfx.click()}catch(e){}try{roamStart()}catch(e){}};
function addSecret(){try{if(S.set&&S.set.roamOn===undefined){S.set.roamOn=false;S.set.hideRoam=true;save();try{roamStart()}catch(e){}}}catch(e){}
 const img=document.querySelector('#s-home .logo .pxlogo');if(!img||img.parentElement.classList.contains('lgwrap'))return;
 const w=document.createElement('span');w.className='lgwrap';img.replaceWith(w);w.appendChild(img);
 w.insertAdjacentHTML('beforeend','<button class="secretroam" data-act="roamSecret" tabindex="-1" aria-hidden="true"></button>')}
/* ---- Teacher banner: a big book on each side ---- */
const BOOKIMG=PXG(['.oooooo..oooooo.','oWWWWWWooWWWWWWo','oWLLLLWooWLLLLWo','oWWWWWWooWWWWWWo','oWLLLLWooWLLLLWo','oWWWWWWooWWWWWWo','oWLLLWWooWWLLLWo','oWWWWWWooWWWWWWo','oWLLLLWooWLLLLWo','oWWWWWWooWWWWWWo','oBBBBBBooBBBBBBo','.oBBBBBBBBBBBBo.','..oooooooooooo..'],{o:'#1a2448',W:'#fff6e0',L:'#9ab0e0',B:'#4a7ac8'}).toDataURL();
function bookBanner(){const b=document.querySelector('#s-home .clsban');if(!b||b.querySelector('.cbbook'))return;
 const inner=document.createElement('div');inner.className='cbmain';while(b.firstChild)inner.appendChild(b.firstChild);
 b.insertAdjacentHTML('beforeend',`<img class="cbbook" src="${BOOKIMG}" alt="">`);b.appendChild(inner);b.classList.add('hasbook')}
new MutationObserver(()=>{try{addSecret();bookBanner()}catch(e){}}).observe(document.body,{childList:true,subtree:true});
/* ---- Settings: kid things only, unless opened as "Devices and reset" from the hub ---- */
const _set=ACT.settings;ACT.settings=function(){const r=_set.apply(this,arguments);try{const box=document.getElementById('mbox');if(!box)return r;
 const mode=window.__guMode;
 if(mode==='devices'){box.querySelectorAll('.setsec').forEach(s=>{if(!s.classList.contains('famsec')&&!s.classList.contains('dangersec'))s.remove()});
  const h=box.querySelector('h2');if(h)h.textContent='Family code and reset';
  const done=[...box.querySelectorAll('[data-act=close]')].pop();if(done)done.outerHTML='<button class="btn" data-act="grownups">BACK</button>'}
 else{box.querySelectorAll('.parsec,.dangersec,.parrow').forEach(s=>s.remove());
  const done=[...box.querySelectorAll('[data-act=close]')].pop();
  if(done&&!box.querySelector('.gurow'))done.insertAdjacentHTML('beforebegin','<section class="setsec gurow"><div class="setrow"><span>Teachers<small class="muted" style="display:block">Progress report, focus mode, teacher dashboard, players, reset</small></span><button class="btn sm volt" data-act="grownups">OPEN</button></div></section>')}
 }catch(e){console.warn(e)}return r};
/* closing anything leaves "devices" mode */
const _md=modal;modal=function(){const mb=document.getElementById('mbox');if(mb)mb.classList.remove('guwide');const r=_md.apply(this,arguments);
 try{const box=document.getElementById('mbox'),dash=box.querySelector('.dashv'),ready=box.querySelector('.cl-big')&&/is ready/.test(box.querySelector('h2')?.textContent||'');
  if((dash||ready)&&!box.querySelector('.tpwrow')){const on=!!tpw(),rb=[...box.querySelectorAll('.rbtns')].pop();
   if(rb)rb.insertAdjacentHTML('beforebegin',`<p class="muted tpwrow" style="text-align:center;margin:12px 0 0">${on?'Teacher password is on.':ready?'Students use this device too?':'Shared device?'} <button class="linkbtn" data-act="tpwSet">${on?'Change teacher password':'Set a teacher password'}</button></p>`)}}catch(e){}
/* anything too wide for the popup gets a wider popup instead of being cut off */
 try{const box=document.getElementById('mbox');const fit=()=>{if(box&&!box.classList.contains('guwide')&&box.scrollWidth>box.clientWidth+2){box.classList.add('guwide');try{fitModal()}catch(e){}}};fit();requestAnimationFrame(fit);setTimeout(fit,150)}catch(e){}
 return r};
const _cm=closeModal;closeModal=function(){window.__guMode='';return _cm.apply(this,arguments)};

/* ---- Players: deleting only from the Grown-ups hub ---- */
const _pl=ACT.players;ACT.players=function(){const r=_pl.apply(this,arguments);try{const box=document.getElementById('mbox');
 if(window.__guMode!=='players')box.querySelectorAll('.pldel').forEach(b=>b.remove());
 else{const c=[...box.querySelectorAll('[data-act=close]')].pop();if(c&&!box.querySelector('.guback'))c.insertAdjacentHTML('beforebegin','<button class="btn alt guback" data-act="grownups">TEACHERS</button>')}}catch(e){}return r};

/* ---- Home: Grown-ups in the header, hero things on the hero card, learning first ---- */
const _rh=renderHome;renderHome=function(){const r=kkSafe(_rh,this,arguments);try{const home=document.getElementById('s-home');if(!home||!S.name)return r;
 const tb=home.querySelector('.topbar');
 if(tb&&!tb.querySelector('.gubtn')){const anchor=tb.querySelector('.clsbtn')||tb.querySelector('.selp');const html=`<button class="btn gubtn" data-act="grownups"><img src="${ICO}" alt="">TEACHERS</button>`;anchor?anchor.insertAdjacentHTML('afterend',html):tb.insertAdjacentHTML('beforeend',html)}
 home.querySelectorAll('.linkbtn[data-to=parents]').forEach(l=>(l.closest('p')||l).remove());
 const hb=home.querySelector('.hbtns'),shop=hb&&hb.querySelector('[data-to=shop]'),change=home.querySelector('[data-act=heroes]');
 if(shop&&change){shop.classList.add('closetbtn');change.insertAdjacentElement('afterend',shop);change.parentElement.classList.add('herobtns')}
 if(hb){const q=s=>hb.querySelector(s);const order=[q('[data-act=play]'),q('[data-to=arcade]'),q('[data-to=map]'),q('[data-act=practice]'),q('[data-to=binder]')].filter(Boolean);
  if(typeof ACT.hiscores==='function'&&(typeof par!=='function'||par('arcade'))){let hs=q('.homehs');if(!hs){hb.insertAdjacentHTML('beforeend',`<button class="btn homehs" data-act="hiscores"><img class="bico" src="${CUP}" alt="">High Scores</button>`);hs=q('.homehs')}const bi=order.indexOf(q('[data-to=binder]'));order.splice(bi<0?order.length:bi,0,hs)}
  {let pg=q('.homeprog');if(!pg){hb.insertAdjacentHTML('beforeend',`<button class="btn homeprog half" data-act="myReport"><img class="bico" src="${CHART}" alt="">Progress Report</button>`);pg=q('.homeprog')}order.push(pg);const bd=q('[data-to=binder]');if(bd)bd.classList.add('half')}
  hb.classList.add('hgrid');const pr=q('[data-act=practice]');if(pr)pr.classList.toggle('half',!!q('.homehs'));const hs2=q('.homehs');if(hs2)hs2.classList.add('half');
  order.forEach(b=>{b.classList.remove('arcbig');if(b.dataset.act!=='play')b.classList.remove('big');hb.appendChild(b)})}
 home.querySelectorAll('.badges.rbadges2,.bdglbl').forEach(x=>x.remove());
 /* preview of the lesson they're on, at the top of the right-hand box */
 const tc=home.querySelector('.tcard .tc-l')||home.querySelector('.tcard');
 if(tc&&!home.querySelector('.nxcard')){try{const n=nextStage(),NS=typeof NST!=='undefined'?NST:8,i=Math.floor(n/NS),s=n%NS,L=LESSONS[i],R=REGIONS[L.r]||{};
  const f=typeof formNow==='function'?formNow(i):0,has=!!S.cards[i+'-'+f];
  const keys=L.k?[...L.k].map(c=>`<span style="--fc:${fcol(fingerOf(c))}">${c.toUpperCase()}</span>`).join(''):'';
  const pips=Array.from({length:NS},(_,k)=>`<i class="${(S.best[i+'-'+k]||0)>0?'done':''} ${k===s?'cur':''}"></i>`).join('');
  tc.insertAdjacentHTML('afterbegin',`<button class="nxcard" data-act="play" data-n="${n}" style="--rc:${R.color||'#7fe8d0'}"><span class="nx-art">${creatureSVG(i,f,'fit '+(has?'':'sil'))}</span><span class="nx-txt"><small>UP NEXT · ${esc(R.name||'')}</small><b>Lesson ${typeof LNUM==='function'?LNUM(i):i+1}: ${esc(lessonTitle(i))}</b><span class="nx-part">Part ${s+1} of ${NS} · ${esc(stageName(i,s))}</span><span class="nx-pips">${pips}</span>${keys?`<span class="minikeys">${keys}</span>`:''}</span></button>`)}catch(e){console.warn(e)}}
 /* layout from Andy's mockup: egg + keystone move under the mode buttons, closet above change hero, arcade|map share a row */
 try{const tr=home.querySelector('.tc-r')||home.querySelector('.tcard'),egg=home.querySelector('.eggrow'),ks=home.querySelector('.shards');
  if(tr&&(egg||ks)){let bot=home.querySelector('.homebot');if(!bot){bot=document.createElement('div');bot.className='homebot'}const hbb=home.querySelector('.hbtns');if(hbb&&hbb.nextElementSibling!==bot)hbb.insertAdjacentElement('afterend',bot);else if(!hbb&&!bot.parentElement)tr.appendChild(bot)
   if(egg&&egg.parentElement!==bot)bot.appendChild(egg);if(ks&&ks.parentElement!==bot)bot.appendChild(ks)}
  const hbx=home.querySelector('.herobtns'),cl=hbx&&hbx.querySelector('.closetbtn');if(cl&&hbx.firstElementChild!==cl)hbx.insertBefore(cl,hbx.firstElementChild);
  if(hb){['[data-to=arcade]','[data-to=map]'].forEach(s=>{const b=hb.querySelector(s);b&&b.classList.add('half')})}
 }catch(e){console.warn(e)}
 }catch(e){console.warn(e)}return r};
/* the home's two-column fitter re-sorts children; keep the egg/keystone row right under the mode buttons */
if(typeof homeCols==='function'){const _hc=homeCols;homeCols=function(){const r=_hc.apply(this,arguments);try{const b=document.querySelector('#s-home .homebot'),h=document.querySelector('#s-home .hbtns');if(b&&h&&h.nextElementSibling!==b)h.insertAdjacentElement('afterend',b)}catch(e){}return r}}
document.head.insertAdjacentHTML('beforeend',`<style>
#s-home .topbar .btn.gubtn{background:#f0c860!important;color:#2a1d3e!important;box-shadow:4px 4px 0 rgba(4,6,24,.65)!important;height:42px!important;font-family:var(--title)!important;font-size:11px!important;padding:0 10px!important;letter-spacing:.04em;display:inline-flex;align-items:center;gap:6px;margin:0!important;min-height:0!important;line-height:1!important}
#s-home .topbar .btn.gubtn img{height:18px;image-rendering:pixelated}
.gugrid{display:grid;grid-template-columns:1fr 1fr;gap:10px;text-align:left}
.guitem{font:inherit;display:flex;flex-direction:column;gap:4px;padding:14px 16px;background:#1b1626;border:3px solid #3a2f4e;border-left-width:10px;color:#fff6e0;cursor:pointer;text-align:left}
.guitem:hover{background:#2a2238}.guitem b{font-size:22px}.guitem small{font-size:16px;color:#c8bce0}
.guitem.c1{border-left-color:#7fe8d0}.guitem.c2{border-left-color:#f0c860}.guitem.c3{border-left-color:#7fc8f0}.guitem.c4{border-left-color:#b8a0f0}.guitem.c5{border-left-color:#f07a6e}
#mbox .dashv .cl-racebtn{display:flex;justify-content:center;margin-top:12px}#mbox .dashv .cl-racebtn .btn{width:100%;font-family:var(--title)!important;font-size:18px!important;letter-spacing:.06em;padding:16px 12px!important;text-transform:uppercase}
#mbox .dashv .cl-lvl{justify-content:center}
#mbox .dashv>.rbtns{margin-top:26px!important}
.tcounts{display:inline-flex;align-items:center;gap:14px}.tcount{display:inline-flex;align-items:center;gap:6px}.tcount .tico{width:22px;height:22px;image-rendering:pixelated}
#s-home .clsban{max-width:640px;margin:4px auto 8px!important;background:#1c2f6e!important;border:4px solid #7fc8f0!important;box-shadow:6px 6px 0 #0d0a16!important;padding:6px 14px!important;color:#fff6e0;display:grid;gap:2px}
#s-home .clsban .cb-name{color:#bfe2f6!important;font-size:16px}
#s-home .clsban .cb-row{gap:12px;padding:0;margin:0!important}#s-home .clsban .cb-row>span:first-child{font-size:20px;color:#fff6e0;line-height:1.1}#s-home .clsban .cb-row b{color:#f0c860;font-weight:400}
#s-home .clsban .cb-row .btn{margin:3px 0 5px!important;min-width:110px;padding-top:6px!important;padding-bottom:6px!important}
#s-home .clsban .cb-name{line-height:1;margin:0}
#s-home .roamtog{display:none!important}
#s-home .topbar{justify-content:flex-start!important}#s-home .topbar>.selp{margin-right:auto!important}
#s-home .visrow,body.mobile #s-home .tcard .visrow,body.mobile #s-home .visrow.visrow{display:none!important}
#s-home .hbtns{grid-template-rows:none!important;grid-auto-rows:auto!important;margin-top:10px!important}#s-home .hbtns>.btn{min-height:52px!important;height:auto!important;font-size:22px!important}#s-home .hbtns>.btn.big{font-size:24px!important}
#s-home .nxcard{margin-bottom:16px!important}#s-home .tc-l .daily{margin-bottom:14px}
#s-home .lgwrap{position:relative;display:inline-block;line-height:0}
#s-home .lgwrap .secretroam{all:unset;position:absolute;left:77.9%;top:36%;width:3.4%;height:10%;cursor:default;opacity:0;z-index:2}
#s-home .clsban.hasbook{display:flex!important;flex-direction:row!important;flex-wrap:nowrap!important;align-items:center;gap:14px;max-width:760px}
#s-home .clsban .cbmain{flex:1;min-width:0;display:grid;gap:2px}
#s-home .clsban .cbbook{width:64px;height:auto;image-rendering:pixelated;flex:none;filter:drop-shadow(3px 3px 0 #0d0a16)}
body.mobile #s-home .clsban .cbbook{width:40px}
.medal{display:inline-grid;place-items:center;width:30px;height:30px;font:400 15px/1 var(--title,monospace);color:#241c34!important;box-shadow:inset -3px -3px 0 rgba(0,0,0,.3),inset 3px 3px 0 rgba(255,255,255,.5)!important;clip-path:polygon(30% 0,70% 0,70% 7%,85% 7%,85% 15%,93% 15%,93% 30%,100% 30%,100% 70%,93% 70%,93% 85%,85% 85%,85% 93%,70% 93%,70% 100%,30% 100%,30% 93%,15% 93%,15% 85%,7% 85%,7% 70%,0 70%,0 30%,7% 30%,7% 15%,15% 15%,15% 7%,30% 7%);padding-top:1px;box-sizing:border-box}
.medal.m1{background:#f0c860}.medal.m2{background:#c8d0dc}.medal.m3{background:#d08a50}
#s-home .homebot{display:grid;grid-template-columns:1fr auto;gap:12px;margin-top:14px;align-items:stretch}
#s-home .homebot .eggrow{margin:0!important;display:flex;align-items:center;gap:14px;padding:12px 16px!important}
#s-home .homebot .eggrow b{font-size:24px}#s-home .homebot .eggrow .note{font-size:19px}
#s-home .homebot .shards{margin:0!important;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;padding:8px 14px!important;min-width:0}
#s-home .homebot .shards .sh-row{display:grid!important;grid-template-columns:repeat(5,auto);gap:6px 8px}
#s-home .homebot .shards .sh-lab{font-size:18px}
#s-home .herobtns{margin-top:14px}
body.mobile #s-home .homebot{grid-template-columns:1fr}
#mbox .cl-list{display:flex;flex-wrap:wrap;gap:8px;justify-content:center}
#mbox .btn .muted{color:#4a3a1a!important;opacity:1!important}
#mbox.guwide{width:min(940px,96vw)!important;max-width:none!important;overflow-x:auto}
#mbox .hs-tab td,#mbox .hs-tab th{padding-left:8px;padding-right:8px}
#mbox .hs-tabs{flex-wrap:wrap!important}
@media (max-width:600px){#mbox .hs-tab{font-size:14px!important;width:100%}#mbox table.hs-tab.hs-tab td,#mbox table.hs-tab.hs-tab th{padding:4px 3px!important;font-size:15px!important}#mbox .hs-tab th:nth-last-child(1),#mbox .hs-tab td:nth-last-child(1),#mbox .hs-tab th:nth-last-child(2),#mbox .hs-tab td:nth-last-child(2){display:none}#mbox .hs-tabs button{font-size:13px!important;padding:4px 6px!important}}
.gusupport{margin:12px 0 0;font-size:17px;color:#c8bce0}.gusupport a{color:#f07a6e}
.gugrid .guitem:last-child:nth-child(odd){grid-column:1/-1}
#s-home .hbtns{display:grid!important;grid-template-columns:1fr 1fr!important;row-gap:11px!important;column-gap:6px!important}
#s-home .hbtns>.btn{grid-column:1/-1!important;width:100%!important;margin:0!important}
#s-home .hbtns>.btn.half{grid-column:auto!important}
#s-home .hbtns>.homehs{background:#c83a5c!important;color:#fff6e0!important;box-shadow:0 5px 0 #8a2240!important}
.nxcard{font:inherit;color:inherit;text-align:left;cursor:pointer;display:grid;grid-template-columns:84px 1fr;gap:14px;align-items:center;width:100%;padding:8px 14px;margin:0 0 10px;background:#1b1626;border:3px solid #3a2f4e;border-left:10px solid var(--rc);box-sizing:border-box}
.nxcard:hover{background:#241c36}.nx-art{width:84px;height:72px;overflow:hidden;position:relative;background:#120e1e;border:3px solid #3a2f4e}.nx-art>svg{position:absolute!important;left:50%!important;top:50%!important;width:210px!important;height:210px!important;max-width:none!important;margin:-112px 0 0 -105px!important;transform:none!important}.nx-art>svg.sil{filter:brightness(0) drop-shadow(0 0 3px #7fe8ff)!important;opacity:.85!important}
.nx-txt{display:flex;flex-direction:column;gap:3px;min-width:0}.nx-txt small{font-size:15px;color:var(--rc);letter-spacing:.06em}.nx-txt b{font-size:24px;color:#fff6e0;font-weight:400;line-height:1.1}
.nx-part{font-size:17px;color:#c8bce0}.nx-pips{display:flex;gap:4px;margin:2px 0}.nx-pips i{width:16px;height:8px;background:#3a2f4e}.nx-pips i.done{background:#f0c860}.nx-pips i.cur{background:#7fe8d0;box-shadow:0 0 0 2px #fff6e0}
.nxcard .minikeys{display:flex;gap:4px;margin-top:2px}.nxcard .minikeys span{min-width:24px;height:24px;display:grid;place-items:center;font-size:15px;background:var(--fc);color:#2a1d3e;padding:0 4px}
#s-home .hbtns>.btn.big{margin-bottom:10px!important}
#s-home .footbtns .instabtn{background:linear-gradient(to bottom,#b4469e 0 34%,#cf3f7c 34% 68%,#e0605e 68%)!important;color:#fff!important;text-shadow:1px 1px 0 #2a1d3e,-1px 1px 0 #2a1d3e,1px -1px 0 #2a1d3e,-1px -1px 0 #2a1d3e}
#s-home .footbtns .kofibtn{background:#f07a6e!important;color:#2a1d3e!important;display:inline-flex;align-items:center;gap:6px}#s-home .footbtns .kofibtn img{height:16px;image-rendering:pixelated}
#s-home .footbtns .howtobtn{background:#6edc8c!important;color:#16301e!important}
#s-home .topbar .btn.selp,#s-home .topbar .btn.clsbtn,#s-home .topbar .btn.gubtn{font-family:var(--display)!important;font-size:22px!important;letter-spacing:.06em!important;text-transform:uppercase}
#mbox :is(p,small,li,td,label,.note,.muted,.cl-note,.setrow span):not(.pgq){font-size:20px!important}
#mbox .cl-sec,#mbox .raceHubBox{text-align:center}#mbox .cl-sec .cl-btns,#mbox .cl-sec .clfield,#mbox .cl-sec>div{justify-content:center;margin-left:auto;margin-right:auto}
.gurepname{text-align:center;margin:18px 0 10px}
.gutabs{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:0 0 14px}.gutabs .btn.on{background:#f0c860!important;color:#2a1d3e!important}
.guall{width:100%;border-collapse:collapse;margin:0 0 14px;font-size:18px}.guall th,.guall td{padding:6px 10px;border-bottom:2px solid #3a2f4e;text-align:left}.guall tr.on td{color:#f0c860}
#s-home .herobtns{display:grid!important;grid-template-columns:1fr;gap:8px}
#s-home .herobtns>.btn{width:100%;margin:0!important}
#s-home .closetbtn{background:#a8d878!important;color:#2a1d3e!important}
</style>`);
try{if(screen==='home')renderHome()}catch(e){}
})();
/* master code works at every grown-up math check */
document.addEventListener('focusin',e=>{const t=e.target;if(t&&t.classList&&t.classList.contains('pgin')&&t.maxLength<10)t.maxLength=10},true);

if(ACT.clsGateOk){const _c=ACT.clsGateOk;ACT.clsGateOk=function(){const c=kkCode('pgate2');if(c){if(c==='done'){window.__clsOk=1;closeModal()}return}return _c.apply(this,arguments)}}
if(ACT.parCheck){const _p=ACT.parCheck;ACT.parCheck=function(){const c=kkCode('pgate');if(c){if(c==='done')closeModal();return}return _p.apply(this,arguments)}}
/* wider stats column so 5-digit XP and 3-digit Keylori never touch */
document.head.insertAdjacentHTML('beforeend','<style>#s-home .hero-info,#s-home.wide .hero-info{max-width:380px!important}#s-home .hero-info .trow{grid-template-columns:auto auto auto!important;justify-content:space-between;column-gap:26px!important;padding:0 6px;box-sizing:border-box}#s-home .hero-info .trow div{white-space:nowrap}</style>');
/* unlimited diamonds after the master code: topped back up whenever they're spent */
(function(){const fill=()=>{try{if(S&&S.infGems&&S.gems<99999)S.gems=99999}catch(e){}};
const _s=save;save=function(){fill();return _s.apply(this,arguments)};
const _r=renderHome;renderHome=function(){fill();return kkSafe(_r,this,arguments)};
const _m=modal;modal=function(){fill();return _m.apply(this,arguments)};fill()})();
/* arcade header: trophy icon on the High Scores button (shown alone on phones) */
(function(){const add=()=>{document.querySelectorAll('.hsbtn:not(.hascup)').forEach(b=>{b.classList.add('hascup');const t=b.textContent.trim();b.setAttribute('aria-label',t);b.title=t;b.innerHTML=`<img class="bico mcup" src="${window.KK_CUP}" alt=""><span class="hslbl">${t}</span>`})};
const _sh=show;show=function(){const r=_sh.apply(this,arguments);setTimeout(add,0);return r};add();
document.head.insertAdjacentHTML('beforeend','<style>.hsbtn .mcup{display:none}body.mobile .hsbtn .mcup{display:block;height:20px;width:auto;margin:0;image-rendering:pixelated}body.mobile .hsbtn .hslbl{display:none}body.mobile .hsbtn{width:40px;padding:0!important;display:inline-flex;align-items:center;justify-content:center}</style>')})();
document.head.insertAdjacentHTML('beforeend','<style>#s-home .homeprog{background:#a8d878!important;color:#2a1d3e!important;box-shadow:0 5px 0 #6fa048!important}#s-home .homeprog:active{box-shadow:0 2px 0 #6fa048!important}</style>');
/* one reusable grown-up check (same math box, same secret codes) for anything kids shouldn't open alone */
(function(){let NEXT=null,ANS=0;
window.kkGate=(cb,why)=>{if(window.__gu)return cb();NEXT=cb;const a=6+Math.floor(Math.random()*4),b=3+Math.floor(Math.random()*7);ANS=a*b;
 modal(`<h2>GROWN-UPS ONLY</h2><p class="muted" style="margin:0 0 8px">${why||'Quick check before you go in.'}</p><div class="pgatebox"><p class="pgq">What is ${a} × ${b}?</p><input id="kkgate" class="pgin" inputmode="numeric" autocomplete="off" maxlength="10" aria-label="Answer" data-enter="kkGateOk"></div>
 <div class="rbtns"><button class="btn" data-act="kkGateOk">OK</button><button class="btn alt" data-act="close">BACK</button></div>`);setTimeout(()=>document.getElementById('kkgate')?.focus(),50)};
ACT.kkGateOk=()=>{const c=window.kkCode?kkCode('kkgate'):null;if(c==='own')return;const v=+(document.getElementById('kkgate')?.value||0);
 if(c!=='done'&&v!==ANS){try{sfx.bad()}catch(e){}toast('Not quite. Ask a grown-up!');return closeModal()}window.__gu=1;const f=NEXT;NEXT=null;closeModal();f&&f()};
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target&&e.target.id==='kkgate'){e.preventDefault();e.stopPropagation();ACT.kkGateOk()}},true);
if(ACT.feedback){const _fb=ACT.feedback;ACT.feedback=function(){const args=arguments;kkGate(()=>{_fb.apply(this,args);const m=document.querySelector('#mbox .muted:last-of-type');const p=[...document.querySelectorAll('#mbox p.muted')].find(x=>/Only your message/.test(x.textContent));if(p)p.innerHTML='For grown-ups. Only your message, type and optional email are sent. Please leave out children\'s full names. <a href="/privacy/" target="_blank" style="color:#7fe8d0">Privacy</a>'},'Feedback is sent to the game maker, so a grown-up should write it.')}}
})();
