/* Keyloria Run add-on: two new segment types.
   FORK  ('fork'): two keycaps at once. HIGH = big jump up onto a gem ledge (riskier), LOW = normal hop over a rock.
   FLAP  ('flap'): the hero grabs a balloon; each correct letter = one flap; float through gaps in pipes, clouds and thorny vines.
   Everything is built through RUNNER.SEG and the build / update / drawWorld / drawTop hooks. */
(function(){
if(!window.RUNNER)return;
try{
const C=RUNNER.C,GROUND=C.GROUND,RX=C.RX,BW=C.BW,GRAV=C.GRAV,HOP=C.HOP,JV=C.JV;
const HK=RUNNER.HK,SEG=RUNNER.SEG;
const HI_SCALE=1.25,LH=40;                       // big-jump strength, ledge height above ground
const FG=85,GS0=58,PW=14;                        // flap gravity, base pipe gap size, pipe width
const rr=()=>RUNNER.R;
const height=()=>-rr().y;
const heroH=()=>{try{return RUNNER.HERO?RUNNER.HERO.height:28}catch(e){return 28}};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const irnd=(a,b)=>a+Math.floor(Math.random()*(b-a+1));
const ROCK=RUNNER.PX(["....oooo....","..ooLLHLoo..",".oLLLHHLLMo.",".oLLLLLLMMo.","oLLLLLLMMMMo","oMLLLLMMMMDo","oMMLLMMMMDDo","oMMMMMMMDDDo",".oDMMMMDDDo.","..oooooooo.."],{o:'#1e1a2a',H:'#c8c8d8',L:'#9a9ab0',M:'#74748e',D:'#55556e'});
const ARROW=RUNNER.PX(["...Y...","..YYY..",".YYYYY.","YYYYYYY","..YYY..","..YYY.."],{Y:'#f0c860'});
const BALLOON=RUNNER.PX(["...oooo...","..orrrro..",".orHHrrro.",".orHrrrro.",".orrrrrro.",".orrrrDro.","..orrrDo..","..oorDoo..","...oooo...","....oo...."],{o:'#4a1020',r:'#ff6b7a',H:'#ffd0d8',D:'#c8404f'});
const capO=(o,k,ch,x,y,st)=>{if(o&&o.cap){try{return o.cap(k,ch,x,y,st)}catch(e){}}RUNNER.cap(ch,x,y,st)};   // o.cap(k,ch,x,y,st): optional drawer (Math / Spelling show a problem instead of the keycap)
const pickKey=(keys,caps,not)=>{for(let i=0;i<40;i++){let k=keys[Math.floor(Math.random()*keys.length)];if(caps&&/[a-z]/.test(k)&&Math.random()<.15)k=k.toUpperCase();if(!not||not.every(n=>n.toLowerCase()!==k.toLowerCase()))return k}return keys[0]};

/* ---------- shared helpers ---------- */
function shiftFrom(R,cut,ex){if(ex<=0)return;R.obs.forEach(o=>{if(o.x>=cut)o.x+=ex});R.gems.forEach(g=>{if(g.x>=cut)g.x+=ex});R.bossX+=ex}
function bonkAt(R,o,x){ // same recipe as the engine's rock bonk
  R.bonks++;R.streak=0;R.shake=3;R.stun=R.L.hard?.45:.25;R.kb=R.L.hard?-70:0;R.speed=0;R.front=x;R.cam=R.front-RX;
  if(R.air){R.air=false;R.y=0;R.vy=0}if(R.jt){R.jt.jt=false;R.jt=null}
  RUNNER.popTxt('BONK!',o.x+o.w/2,GROUND-30,'#ff6b7a');RUNNER.snd(120,.15,'square',.07);RUNNER.burst(o.x-R.cam,GROUND-8,'#ffffff',6,40)}
function grabGems(R){R.gems.forEach(gm=>{if(!gm.got&&gm.x>R.front-BW-4&&gm.x<R.front+2&&(GROUND-gm.y)>=height()-6&&(GROUND-gm.y)<=height()+24){gm.got=1;R.gemN++;RUNNER.snd(1175,.06,'square',.04);RUNNER.burst(gm.x-R.cam,gm.y,'#8ff0ff',5,40)}})}

/* ================= FORK ================= */
SEG.fork={
  want:o=>o.st==='wait'?o.hi+o.lo:'',
  done:o=>o.st!=='wait',
  strip:o=>[o.hi,'/',o.lo],
  typed:o=>o.st!=='wait'?3:0,
  key(o,ch){const R=rr();
    if(R.air){R.hits--;R.typed--;R.streak--;return}          // typed ahead while in the air: ignore, like rocks
    if(o.st!=='wait')return;
    if(ch===o.hi){o.st='hi';o.ph=height();R.jumpScale=HI_SCALE;try{RUNNER.jump(o)}finally{R.jumpScale=1}}
    else{o.st='lo';R.jumpScale=1;RUNNER.jump(o)}
  },
  update(o,dt){const R=rr();if(R.phase!=='run')return;const back=R.front-BW;
    if((o.st==='wait'||o.st==='lo')&&R.front>o.x+1&&back<o.x+o.w-1&&height()<o.h-2){bonkAt(R,o,o.x-(R.L.hard?3:10));o.st='wait';o.jt=false;RUNNER.updStrip();return}
    if(o.st==='lo'){
      if(back>o.x+o.w){o.st='done';o.done=true;if(o.nice){R.nice++;RUNNER.popTxt('NICE!',o.x+o.w/2,GROUND-34,'#4de08a');RUNNER.snd(988,.05,'square',.04);RUNNER.snd(1319,.08,'square',.04,.05)}RUNNER.updStrip()}
      else if(o.jt===false){o.st='wait';RUNNER.updStrip()}                 // engine landed us early ("TOO SOON")
    }
    if(o.st==='drop'&&!R.air){o.st='done';o.done=true;RUNNER.updStrip()}
  },
  block:o=>(o.st==='wait'&&!rr().L.hard)?o.x-10:null,
  draw(){}                                                                  // drawn in drawWorld (the section is wider than the engine's cull)
};

function forkHook(R,dt){
  const o=R.obs.find(f=>f.t==='fork'&&(f.st==='hi'||f.st==='ledge'));if(!o)return false;
  const px0=o.x+o.p0,px1=px0+o.LW;
  if(o.st==='hi'){
    const prev=height();R.stun=Math.max(0,R.stun-dt);R.front+=R.jumpV*dt;R.cam=R.front-RX;R.vy+=GRAV*dt;R.y+=R.vy*dt;const h=height();grabGems(R);
    if(R.vy>0&&prev>=LH&&h<=LH&&R.front>px0+3&&R.front-BW<px1-2){          // landed on the ledge
      R.y=-LH;R.vy=0;o.st='ledge';R.jt=null;o.jt=false;R.nice++;
      RUNNER.popTxt('HIGH!',R.front-BW/2,GROUND-LH-34,'#f0c860');RUNNER.snd(784,.06,'square',.05);RUNNER.snd(1047,.1,'square',.05,.06);RUNNER.burst(RX-BW/2,GROUND-LH,'#f0c860',8,40)}
    else if(R.y>=0){                                                       // came down on the ground
      R.y=0;R.vy=0;R.air=false;R.jt=null;o.jt=false;RUNNER.snd(110,.05,'triangle',.08);
      if(R.front-BW>px1||R.front-BW>o.x+o.w+1){o.st='done';o.done=true}   // sailed over the rock (even without reaching the ledge): cleared, no rewind
      else{o.st='wait';RUNNER.popTxt('TOO SOON',o.x+o.w/2,GROUND-34,'#b8c0e8');if(R.front>o.x-8){R.front=o.x-8;R.cam=R.front-RX}R.speed=0;R.kb=0;R.stun=.2}   // back to a spot where a jump from rest always clears the rock
      RUNNER.updStrip()}
    return true}
  // on the ledge: run along it, collect gems, step off the end
  const want=R.v*(1+Math.min(R.streak,10)*.025);R.speed+=(want-R.speed)*Math.min(1,dt*3);R.kb=0;
  R.front+=R.speed*dt;R.cam=R.front-RX;R.y=-LH;R.vy=0;R.air=true;grabGems(R);
  if(R.front-BW>px1-2){o.st='drop';R.air=true;R.vy=0;R.jumpV=Math.max(R.speed,HOP);R.jt=null}
  return true}

/* ================= FLAP =================
   Entry: only when the hero stands on the ground with nothing else going on (typing early is ignored, never a miss).
   While flying the hero keeps a fixed screen x and runs at EXACTLY the normal run pace (R.v with the usual combo bonus): no slowdown.
   The gaps are laid out when the flight starts (anchored to the hero, never behind him), their spacing scales with the run speed so every
   gap gives about the same TIME to react as a normal level, and they get a little taller at high speed. The hero only waits (brakes right
   in front of a pillar) when a letter is really late. The same letter can be pressed as often as you like: every press is one flap.
   Exit: balloon pops, hero drifts down at the same pace. */
const FLY_TOP=14;                                     // hero's head never goes above this screen y (below the HUD bars)
const hMax=()=>Math.max(30,GROUND-heroH()-FLY_TOP);
const ambush=()=>{try{return RUNNER.action&&RUNNER.action.state()}catch(e){return null}};
const baseV=R=>{const a=ambush();return R.v/((a&&a.mult)||1)};          // run speed without a blast boost
function reactT(R){                                   // seconds between two gaps: about 1.2 on easy tiers down to 0.7 on late ones
  const L=R.L||{};let T;
  if(L.tier!=null)T=1.25-.05*(+L.tier||0);else if(L.hard)T=.72;else T=[1.3,1.3,1.2,1.1,.95,.85][clamp(RUNNER.opt.lv|0,0,5)];
  return clamp(T,.65,1.3)}
// (re)place the gaps of section o so that gap 0 sits `lead` px after anchor; returns the x where the section ends
function layout(R,o,anchor,leadMin){
  const v=baseV(R),T=reactT(R);
  const pitch=clamp(Math.round(v*1.15*T),64,340),gs=clamp(GS0+Math.round((v-90)/10),GS0,70);
  const lead=Math.max(leadMin||0,clamp(Math.round(v*1.15*(T+.45))+20,90,Math.max(90,C.W-RX-24)));
  const lo=Math.round(gs/2)+8,hi=84-Math.round(gs/2);
  o.gs=gs;o.pitch=pitch;o.lead=lead;
  o.gaps.forEach((p,i)=>{if(p.c0==null)p.c0=p.c;p.c=clamp(p.c0,lo,hi);p.x=Math.round(anchor)+lead+i*pitch});
  const tail=Math.round(PW+14+v*1.7+60);
  return o.gaps[o.n-1].x+PW+tail}
function relocate(R,o,newEnd){                         // move everything after the section so the spacing after it stays right
  const i=R.obs.indexOf(o),nx=R.obs[i+1],oldEnd=o.x+o.w;
  let ex=nx?newEnd+80-nx.x:newEnd+140-R.bossX;
  if(ex<0&&nx&&nx.x+ex-R.cam<C.W+40)ex=0;               // never pull something visible closer
  if(ex<0&&!nx)ex=0;
  if(ex)shiftAny(R,nx?nx.x-14:o.x+1,ex);
  o.w=newEnd-o.x}
function shiftAny(R,cut,ex){R.obs.forEach(q=>{if(q.x>=cut&&q.t!=='flap')q.x+=ex});R.gems.forEach(g=>{if(g.x>=cut)g.x+=ex});R.bossX+=ex}
function ambushBusy(){const a=ambush();return !!(a&&(a.mode||(a.blobs&&a.blobs.length)))}
function flapReady(o,R){return !R.air&&R.stun<=0&&!R.jt&&Math.abs(R.vy)<1&&height()<1&&RUNNER.target()===o&&!ambushBusy()}
function flapStart(o,R){
  // lay the gaps out in front of the hero now (if the start was delayed so much that the first gap was about to pass him,
  // the pillars were hidden and now come in from the right edge)
  const end=layout(R,o,R.front,o.hold?C.W-RX+16:0);
  relocate(R,o,end);o.hold=false;
  if(R.air)R.speed=Math.max(R.speed,R.jumpV||0);
  o.st='fly';R.air=true;R.jt=null;R.vy=Math.min(R.vy,-35);R.kb=0;o.hit=[];o.pl='';o.pt=-9;o.pulse=0;o.gcool=0;o.bv=0;o.slow=0;o.assist=0;o.cool=0;o.bumps=0;o.sndT=-9;
  RUNNER.popTxt('FLY!',R.front-BW/2,GROUND-60,'#ff6b7a');RUNNER.snd(660,.08,'square',.05);RUNNER.snd(880,.1,'square',.05,.07);RUNNER.burst(RX-BW/2,GROUND-height()-heroH()-6,'#ff6b7a',10,45)}
function flapUp(o,R,first){
  const hh=heroH(),h=height(),gp=o.gaps[o.k],gs=o.gs||GS0;let vy=62;
  if(gp){const t=.42,tf=gp.c-hh/2,gt=gp.c+gs/2,Z=Math.max(100,R.speed*.7);
    vy=clamp((tf-h+.5*FG*t*t)/t,26,118);                           // each flap aims at the current gap
    if(h>tf+8)vy=Math.min(vy,10);                                  // already high enough: just a tiny hop, so tapping keeps him floating
    if(gp.x-R.front<Z&&h+hh>gt-8)vy=Math.min(vy,4)}                // never push him up into the top pillar
  R.vy=Math.min(R.vy,-vy);o.pulse=.14;
  const quiet=R.t-o.sndT<.09;                                      // held keys / mashing: no wall of sound
  if(!quiet){o.sndT=R.t;
   if(first){RUNNER.snd(520+o.k*45,.07,'square',.05);RUNNER.snd(780+o.k*45,.06,'triangle',.04,.04)}
   else{RUNNER.snd(300+Math.floor(Math.random()*5)*14,.05,'triangle',.04);RUNNER.snd(430,.04,'square',.02,.03)}
   RUNNER.burst(RX-BW/2,GROUND-height()+1,'#ffffff',first?5:3,28)}}
function flapPress(o,R,k){
  const first=!o.hit[k==null?o.k:k];k=k==null?o.k:k;
  if(first){o.hit[k]=1;R.hits++;R.typed++;R.streak++;R.best=Math.max(R.best,R.streak)}
  flapUp(o,R,first);RUNNER.updStrip()}
SEG.flap={
  want:o=>(o.k<o.n&&(o.st==='pre'||o.st==='fly'))?o.letters[o.k]:'',
  done:o=>o.k>=o.n||o.st==='done',
  strip:o=>o.letters,
  typed:o=>o.k,
  key(o,ch){const R=rr();                                            // fallback only (the key hook below normally handles flap keys)
    if(o.st!=='fly'||o.k>=o.n)return;o.hit[o.k]=1;flapUp(o,R,true)},
  update(o,dt){const R=rr();if(R.phase!=='run')return;
    if(o.st==='pre'){
      layout(R,o,o.x);                                                // keep the pillars tied to the section (other builders may have moved it)
      if(!o.hold&&o.gaps[0].x-R.front<70)o.hold=true;                // the start was delayed (tower, ambush...): hide the pillars, they come in from the right when it starts
      if(R.front>=o.x&&(flapReady(o,R)||(R.front>=o.x+60&&RUNNER.target()===o&&R.stun<=0&&!ambushBusy())))flapStart(o,R)}
  },
  draw(){}
};
// keys: before the flap starts everything is ignored (no mistake, but ambush letters still reach their blob); while flying the current
// letter can be pressed again and again. Held keys (auto-repeat) never count as a first press and never as a mistake.
HK.key.push(function(e){
  const R=rr();if(!R||R.phase!=='run')return false;
  const o=R.obs.find(f=>f.t==='flap'&&(f.st==='pre'||f.st==='fly'||f.st==='pop'||f.st==='fall'));if(!o)return false;
  if(o.k>=o.n){                                                           // all letters done: the last letter pressed again / held is harmless
    if(o.st!=='pre'&&o.pl&&e.key===o.pl&&R.t-o.pt<1.2){if(o.st==='fly')flapUp(o,R,false);return true}
    return false}
  if(o.st==='pop'||o.st==='fall')return false;
  if(RUNNER.target()!==o)return false;
  if(o.st==='pre'){const a=ambush();if(a&&a.blobs&&a.blobs.some(z=>z.st==='in'&&z.ch===e.key))return false;return true}
  const caps=e.getModifierState&&e.getModifierState('CapsLock')&&!e.shiftKey,kk=caps?String(e.key).toLowerCase():e.key;
  if(kk===o.letters[o.k]){if(e.repeat&&!o.hit[o.k])return true;flapPress(o,R);return true}
  if(o.pl&&kk===o.pl&&R.t-o.pt<.6){flapUp(o,R,false);return true}      // still pressing the letter of the gap he just passed: a free flap
  const nx=o.letters[o.k+1];
  if(nx!==undefined&&kk===nx&&!e.repeat){flapPress(o,R,o.k+1);return true}   // next letter typed a little early: counts for that gap (never a mistake)
  if(e.repeat)return true;
  RUNNER.miss();RUNNER.updStrip();return true});

function flapHook(R,dt){
  const o=R.obs.find(f=>f.t==='flap'&&(f.st==='fly'||f.st==='pop'||f.st==='fall'));if(!o)return false;
  const hh=heroH(),hmax=hMax(),fly=o.st==='fly',gs=o.gs||GS0;
  o.slow=Math.max(0,o.slow-dt);o.cool=Math.max(0,o.cool-dt);o.pulse=Math.max(0,o.pulse-dt);o.gcool=Math.max(0,o.gcool-dt);
  // vertical: gentle gravity, soft pull towards the current gap, floor and ceiling
  R.vy+=(o.st==='fall'?GRAV:FG)*dt;
  const gp=o.k<o.n?o.gaps[o.k]:null,Z=Math.max(90,R.speed*.7);
  if(fly&&gp&&gp.x-R.front<Z){const tf=gp.c-hh/2;R.vy-=clamp((tf-height())*(2.5+o.assist),-45-o.assist*20,45+o.assist*20)*dt}
  R.vy=clamp(R.vy,-140,o.st==='fall'?400:60);R.y+=R.vy*dt;
  if(R.y>0){
    if(o.st==='fall'){                                                       // landed: back to running
      R.y=0;R.vy=0;R.air=false;R.jt=null;o.st='done';o.done=true;RUNNER.snd(110,.05,'triangle',.08);RUNNER.burst(RX-BW/2,GROUND,'#e8dcc0',4,25);RUNNER.updStrip();return true}
    const hard=R.vy>28;R.y=0;R.vy=hard?-R.vy*.3:0;                          // bumps along the bottom, never punished
    if(hard&&!o.gcool){o.gcool=.3;RUNNER.snd(130,.04,'triangle',.05);RUNNER.burst(RX-BW/2,GROUND,'#e8dcc0',3,22)}}
  if(-R.y>hmax){R.y=-hmax;R.vy=Math.max(R.vy,0)}
  // horizontal: exactly the normal run pace (same easing as the engine). Only a really late letter makes him wait in front of the pillar.
  let want=R.v*(1+Math.min(R.streak,10)*.025)*(fly&&o.slow>0?.7:1),cap=Infinity;
  if(fly&&gp&&!o.hit[o.k]){                                                   // letter not pressed yet: wait in front of the pillar only if he would not fit through
    const tt=Math.max(0,gp.x-R.front)/Math.max(R.speed,60),hp=height()-(R.vy*tt+.5*FG*tt*tt),gb=gp.c-gs/2,gt=gp.c+gs/2;
    if(hp<gb+6||hp+hh>gt-6)cap=Math.sqrt(2*1200*Math.max(0,gp.x-5-R.front))}
  R.speed+=(want-R.speed)*Math.min(1,dt*(want<R.speed?30:3));if(want<R.speed)R.speed=want;
  if(R.speed>cap)R.speed=cap;
  R.front+=(R.speed+o.bv)*dt;o.bv*=Math.pow(.88,dt*60);if(Math.abs(o.bv)<1)o.bv=0;R.cam=R.front-RX;R.kb=0;R.air=true;
  // the letter moves on once he is through the gap
  if(fly){let ch=false;while(o.k<o.n&&R.front-BW>o.gaps[o.k].x+PW){o.pl=o.letters[o.k];o.pt=R.t;o.k++;ch=true}
    if(ch){if(o.k>=o.n)RUNNER.popTxt('GREAT!',R.front-BW/2,GROUND-height()-hh-34,'#4de08a');RUNNER.updStrip()}}
  // soft bump on pipes / vines
  if(fly&&!o.cool){const h=height();
    for(const p of o.gaps){if(R.front-2>p.x&&R.front-BW+2<p.x+PW){
      const gb=p.c-gs/2,gt=p.c+gs/2;
      if(h+3<gb||h+hh-3>gt){o.bumps++;o.assist=Math.min(4,o.assist+1.5);o.cool=.45;o.slow=.5;o.bv=-90;R.front=Math.min(R.front,p.x-1);R.cam=R.front-RX;R.vy=h+3<gb?-50:40;R.shake=1;
        RUNNER.popTxt('OOF!',p.x+PW/2,GROUND-clamp(h+hh+10,30,76),'#b8c0e8');RUNNER.snd(150,.12,'square',.06);RUNNER.burst(p.x-R.cam,GROUND-h-hh/2,'#ffffff',6,35);break}}}}
  // all letters done and past the last gap: pop the balloon, drift down at the same pace
  if(fly&&o.k>=o.n){const lp=o.gaps[o.gaps.length-1];if(R.front-BW>lp.x+PW+14){o.st='pop';o.pt=.3;
    RUNNER.popTxt('POP!',R.front-BW/2,GROUND-height()-hh-26,'#ffd0d8');RUNNER.snd(220,.12,'sawtooth',.06);RUNNER.snd(1319,.05,'square',.04,.03);
    RUNNER.burst(RX-BW/2,GROUND-height()-hh-14,'#ff6b7a',14,70);RUNNER.burst(RX-BW/2,GROUND-height()-hh-14,'#ffffff',6,50)}}
  else if(o.st==='pop'){o.pt-=dt;if(o.pt<=0)o.st='fall'}
  return true}

/* ---------- build: place forks and one flap section ---------- */
function build(R){
  const opt=RUNNER.opt,hard=!!R.L.hard;
  const keys=[...R.L.keys],caps=!!R.L.caps;
  // flap section: once per run, level index >= 2 and super hard
  if((hard||opt.lv>=2)&&R.obs.length>=4){
    const m=clamp(Math.round(R.obs.length*.5),2,R.obs.length-1),prev=R.obs[m-1],nx=R.obs[m];
    const n=irnd(6,10);
    const room=clamp(Math.round(R.v*1.25*.79*1.15+50),100,290);       // room after the last obstacle for its jump to land
    const fx=Math.round(prev.x+(prev.w||10)+room);
    const letters=[];for(let i=0;i<n;i++)letters.push(pickKey(keys,caps,letters.length?[letters[i-1]]:null));
    const gaps=[];let c=irnd(36,48);for(let i=0;i<n;i++){c=clamp(c+irnd(-12,12),34,52);gaps.push({x:0,c,kind:i%3})}
    const o={t:'flap',x:fx,w:0,n,k:0,letters,gaps,st:'pre',bumps:0,hit:[],hold:false};
    const len=layout(R,o,fx,0)-fx;o.w=len;                              // gaps spaced for this run speed
    const ex=Math.max(0,fx+len+80-nx.x);shiftFrom(R,nx.x-14,ex);
    R.obs.splice(m,0,o);
  }
  // forks: about every 5-6 obstacles, replacing a rock
  const idxs=[];for(let i=irnd(4,5);i<R.obs.length-1;i+=irnd(5,6))idxs.push(i);
  idxs.forEach(i0=>{
    let i=i0;while(i<R.obs.length&&R.obs[i].t!=='rock')i++;
    if(i>=R.obs.length)return;
    const rk=R.obs[i];
    const hi=pickKey(keys,caps),lo=pickKey(keys,caps,[hi]);
    const Vref=Math.max(R.v*1.1,HOP),Vmax=Math.max(R.v*1.25,HOP);
    const d0=clamp(Math.round(Vref*.16),14,34),vy0=-JV*HI_SCALE,tl=(vy0+Math.sqrt(vy0*vy0-2*GRAV*LH))/GRAV;
    const p0=Math.round(-d0+tl*Vref-34),LW=Math.round(.9*Vref)+40,fall=Math.sqrt(2*LH/GRAV)*Vmax;
    const o={t:'fork',x:rk.x,w:rk.w||10,h:rk.h||9,hi,lo,st:'wait',d0,p0,LW};
    const need=o.x+p0+LW+BW+fall+70,nx=R.obs[i+1];
    const nxX=nx?nx.x:R.bossX;
    shiftFrom(R,nxX-14,Math.max(0,Math.ceil(need-nxX)));
    R.obs[i]=o;
    const n=Math.floor((LW-24)/12);for(let j=0;j<n;j++)R.gems.push({x:o.x+p0+12+j*12,y:GROUND-LH-8,got:0});
  });
  R.obs.sort((a,b)=>a.x-b.x);
}
HK.build.push(build);
HK.update.push(function(dt){const R=rr();return forkHook(R,dt)||flapHook(R,dt)});

/* ---------- drawing ---------- */
function drawPipe(g,kind,x,y0,y1,gapAtBottom){
  const hgt=y1-y0;if(hgt<=0)return;
  const T=RUNNER.theme||{},S=T.stone||{},V=T.vine||{},K=T.cl||{};
  if(kind===0){                                                    // stone pillar (Keyloria ruins)
    g.fillStyle=(S.o||'#1e1a2a');g.fillRect(x-1,y0,PW+2,hgt);g.fillStyle=(S.M||'#74748e');g.fillRect(x,y0,PW,hgt);g.fillStyle=(S.L||'#9a9ab0');g.fillRect(x+2,y0,3,hgt);g.fillStyle=(S.D||'#55556e');g.fillRect(x+10,y0,4,hgt);
    g.fillStyle=(S.o||'#1e1a2a');for(let yy=y0+7;yy<y1-1;yy+=8)g.fillRect(x,yy,PW,1);g.fillStyle=(S.G||'#4f7f48');for(let yy=y0+3;yy<y1-1;yy+=16)g.fillRect(x+6+((yy>>4)&1)*3,yy,2,3);
    const ry=gapAtBottom?y1-5:y0;g.fillStyle=(S.o||'#1e1a2a');g.fillRect(x-3,ry,PW+6,5);g.fillStyle=(S.H||'#c8c8d8');g.fillRect(x-2,ry+1,PW+4,3);g.fillStyle=(S.L||'#9a9ab0');g.fillRect(x-2,ry+3,PW+4,1);g.fillStyle=(S.Y||'#f0c860');g.fillRect(x+PW/2-1,ry+1,2,2)
  }else if(kind===1){                                               // cloud column
    const bands=Math.ceil(hgt/6);
    for(let b=0;b<bands;b++){const yy=y0+b*6,hh=Math.min(6,y1-yy),o=(b&1)?-1:1;g.fillStyle=(K.o||'#7a8ec0');g.fillRect(x+o-1,yy,PW+4,hh)}
    for(let b=0;b<bands;b++){const yy=y0+b*6,hh=Math.min(6,y1-yy),o=(b&1)?-1:1;g.fillStyle=(K.b||K.H||'#f4f8ff');g.fillRect(x+o,yy,PW+2,hh);g.fillStyle=(K.L||'#dfe8f4');g.fillRect(x+o+PW-3,yy,5,hh);g.fillStyle=(K.w||'#ffffff');g.fillRect(x+o+1,yy+1,3,2)}
  }else{                                                            // thorny vine
    g.fillStyle=(V.o||'#1e2a1a');g.fillRect(x+4,y0,6,hgt);g.fillStyle=(V.d||'#365f3c');g.fillRect(x+5,y0,4,hgt);g.fillStyle=(V.l||'#4f7f48');g.fillRect(x+6,y0,1,hgt);
    for(let yy=y0+2;yy<y1-2;yy+=8){const L=((yy-y0)>>3)&1;g.fillStyle=(V.t||'#e8e0f0');if(L){g.fillRect(x,yy,5,1);g.fillRect(x+1,yy+1,3,1);g.fillRect(x+2,yy-1,1,1)}else{g.fillRect(x+9,yy,5,1);g.fillRect(x+10,yy+1,3,1);g.fillRect(x+11,yy-1,1,1)}}
    const ty=gapAtBottom?y1-5:y0;g.fillStyle=(V.o||'#1e2a1a');g.fillRect(x+1,ty,12,5);g.fillStyle=(V.l||'#4f7f48');g.fillRect(x+2,ty+1,10,3);g.fillStyle=(V.t||'#e8e0f0');g.fillRect(x+3,ty+1,1,1);g.fillRect(x+6,ty+2,1,1);g.fillRect(x+9,ty+1,1,1)
  }
}
function drawFork(g,o,cam,R,isT){
  const x=o.x-cam,x0=o.x+o.p0-cam,top=GROUND-LH,bob=isT?(Math.floor(R.t*6)%2):0;
  const GN=(RUNNER.theme&&RUNNER.theme.gnd)||{},GV=(RUNNER.theme&&RUNNER.theme.vine)||{};
  // the ledge (a floating one-way platform) with its gems drawn by the engine
  g.fillStyle='#2a1a12';g.fillRect(x0-1,top-1,o.LW+2,10);g.fillStyle=(GN.f||'#b48c5c');g.fillRect(x0,top+2,o.LW,6);
  g.fillStyle=(GN.sp||'#8a6a44');for(let i=4;i<o.LW-4;i+=9){g.fillRect(x0+i,top+4+(i%4),2,1);g.fillRect(x0+i+4,top+6,1,1)}
  g.fillStyle=(GN.t||'#62955a');g.fillRect(x0,top,o.LW,3);g.fillStyle=(GN.th||'#a4c886');g.fillRect(x0,top,o.LW,1);g.fillStyle=(GV.d||'#365f3c');for(let i=2;i<o.LW-2;i+=7)g.fillRect(x0+i,top+2,2,1);
  g.fillStyle='#2a1a12';for(let i=2;i<o.LW-4;i+=10){g.fillRect(x0+i,top+9,5,1);g.fillRect(x0+i+1,top+10,3,1)}
  // the rock for the low road
  {const RK=(RUNNER.thSprite&&RUNNER.thSprite(0))||ROCK;g.drawImage(RK,Math.round(x-1),GROUND-RK.height+1)}
  if(o.st==='wait'){
    const cx=Math.round(x+o.w/2),st=isT?1:0;
    capO(o,'lo',o.lo,cx-2,GROUND-o.h-18-bob,st);
    capO(o,'hi',o.hi,cx-2,GROUND-o.h-42-bob,st);
    g.drawImage(ARROW,cx+1,GROUND-o.h-52-(Math.floor(R.t*4)%2));
  }
}
const capPos=(p,cam)=>{const x=Math.round(p.x-cam)+2;return [clamp(x,1,C.W-14),clamp(GROUND-Math.round(p.c)-6,13,GROUND-15)]};   // always inside the canvas
function drawFlap(g,o,cam,R,isT){
  if(o.x+o.w<cam-10||o.x>cam+C.W+10)return;
  if(o.st==='pre'&&o.hold)return;                                   // start delayed: nothing is shown until it starts
  const gs=o.gs||GS0,live=o.st==='pre'||o.st==='fly';
  o.gaps.forEach((p,i)=>{const x=Math.round(p.x-cam);if(x<-24||x>C.W+10)return;
    const gb=p.c-gs/2,gt=p.c+gs/2,yTop=GROUND-Math.round(gt),yBot=GROUND-Math.round(gb);
    drawPipe(g,p.kind,x,0,yTop,true);drawPipe(g,p.kind,x,yBot,GROUND,false);
    if(i>o.k&&live){const q=capPos(p,cam);capO(o,i,o.letters[i],q[0],q[1],0)}})}   // upcoming letters; the current one is drawn on top of the hero
HK.drawWorld.push(function(g,cam){const R=rr(),t=RUNNER.target();
  R.obs.forEach(o=>{
    if(o.t==='fork'){if(o.x+o.p0+o.LW<cam-6||o.x>cam+C.W+10)return;drawFork(g,o,cam,R,o===t)}
    else if(o.t==='flap')drawFlap(g,o,cam,R,o===t)});
  // let the hero run (not glide) while walking on a ledge
  const f=R.obs.find(o=>o.t==='fork'&&o.st==='ledge');if(f&&R.air){R._pathAir=true;R.air=false}});
HK.drawTop.push(function(g,cam){const R=rr();
  if(R._pathAir){R.air=true;R._pathAir=false}
  const o=R.obs.find(f=>f.t==='flap'&&(f.st==='pre'||f.st==='fly'));if(!o)return;
  if(o.st==='pre'&&o.hold){                                                 // start delayed: the first letter waits at the right edge, where its pillar will come in
    if(RUNNER.target()===o&&o.k<o.n)capO(o,o.k,o.letters[o.k],C.W-14,GROUND-Math.round(o.gaps[o.k].c)-6-Math.floor(R.t*6)%2,0);return}
  if(o.k<o.n){const p=o.gaps[o.k],q=capPos(p,cam);                          // current letter: on top of everything, always inside the canvas
    capO(o,o.k,o.letters[o.k],q[0],q[1]-(o.pulse>0?2:Math.floor(R.t*6)%2),o.st==='fly'?1:0);
    const p2=o.gaps[o.k+1];                                                 // the next letter shows at the right edge before its pillar comes into view
    if(o.st==='fly'&&p2&&Math.round(p2.x-cam)>C.W+10&&Math.round(p.x-cam)<C.W-30){const q2=capPos(p2,cam);capO(o,o.k+1,o.letters[o.k+1],q2[0],q2[1],0)}}
  if(o.st!=='fly')return;
  const hh=heroH(),hx=RX-Math.round(BW/2),top=GROUND-hh-Math.round(height()),sw=Math.round(Math.sin(R.t*3));
  const by=Math.max(11,top-26+(Math.floor(R.t*4)%2)+(o.pulse>0?-2:0)),sl=top-(by+10);
  g.fillStyle='#e8ecff';if(sl>0)g.fillRect(hx+sw,by+10,1,sl);
  g.drawImage(BALLOON,hx-5+sw,by);
});
}catch(e){console.error('[runner-paths]',e)}
})();
