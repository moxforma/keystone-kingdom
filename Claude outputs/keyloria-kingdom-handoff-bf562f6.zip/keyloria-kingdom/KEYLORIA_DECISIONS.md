# Keyloria Kingdom: the owner's decisions (follow these in every new feature)

Game: a browser learning game for kids, from first-time computer users (about 5) up to semi-proficient kids (about 10-11). Live at keyloria.online (marketing landing page); the game itself is at /play. Netlify project "keystone-kingdom", deployed from GitHub. Cross-computer saves use a family code.

## Vision for the streams (new)
- Keyloria has THREE learning streams that live inside ONE game, Keyloria Kingdom: **Typing** (exists), **Math** (new) and **Spelling** (new as a full stream; a spelling mode partly exists in spelling.js).
- All three share the same heroes, Keylori creatures, Scramblers (villains), Keystone, worlds, save file, diamonds/XP, outfits, badges, architecture and UI. They should have similar functions: adventure lessons with parts, stars, Keylori catching and evolution, runner parts, Boss Tests, Lesson Quests map, grown-up tools and classroom features.
- Same age groups as Typing.
- CONTENT: both streams need a full library of words and math questions that fills the whole game (every world, lesson and part), reflecting the ONTARIO curriculum from Junior Kindergarten to Grade 8 (Ontario Mathematics 2020 and Language 2023 for Grades 1-8; the Kindergarten Program for JK/SK). Use Canadian spelling and Canadian money.

## Naming and world
- Game name: Keyloria Kingdom. Creatures: Keylori (singular Keylori). Mascot: Pop. Villains: Scramblers. Catch device: the Keystone. 12 worlds: Keyloria, Whispering Woods, Thunder Peaks, Coral Coast, Sunscorch Dunes, Frostfang Tundra, Glowcap Hollow, Cogwork City, Skyreach Isles, Starfall Citadel, Obsidian Rift, Eclipse Throne.
- Original Pokémon-STYLE creatures. Never real Pokémon or any other copyrighted characters.

## Look and feel
- Pixel art at the quality of Zelda: A Link to the Past: detailed, hand-pixeled 16-bit style, less saturated (not primary colours), characters that read as characters. HARD PIXELS: no blur, no anti-aliasing, whole-number scaling, no smooth rotation. Not anime or cel-shaded, not clip-art.
- Should appeal to a 7-year-old Pokémon fan without looking too young.
- Punchy, dimensional graphics, lots of animation, a fun mascot, levels and prizes.
- Laser-shooting play on keypress (a kid version of Typing of the Dead) is the classic mode.

## Kid-facing text and pacing
- Kid-facing text: MINIMAL, basic language, very little description or instruction.
- Slow, kid-paced progression. Finger-position reinforcement for typing.
- SPACE is the continue key across the whole game. Keep new modes consistent.
- Never punishing: no game over and no lives. Mistakes cost time, combo or stars.
- Typing text should be fun, true, educational facts for kids rather than nonsense sentences.

## Engagement and business
- Don't go too hard on engagement hooks (no quests grind, no season pass). It's educational. Chosen instead: class/friend leaderboards, classroom accounts, live race rooms.
- Preparing for possible monetization; classroom features are the focus (teacher dashboard, assignments, focus mode).
- A donation button (Ko-fi). Public-facing material must not be tied closely to the owner personally.
- Mobile is on ice: phone visitors get a notice to use a real keyboard (keep it).

## Runner (Keyloria Run) decisions
- Runner parts are mixed INTO lessons: within each lesson, part 1 is classic, part 2 runner, part 3 classic, and so on (parts 2, 4, 6 and 8 are runners). Every lesson group has runner parts.
- Each Boss Test starts as a classic lesson and ends as a runner-style boss battle (with the "type a sentence" spell mechanic kept).
- Runners and bosses get harder and faster in later worlds. Runner backgrounds match each world.
- Runner modes do NOT count toward WPM.
- Keyloria Run is NOT an Arcade game; it lives in the main lesson mode.
- The runner is a simple, replayable arcade feel (Flappy Bird, Angry Birds, Cut the Rope), with player control: timed jumps, forks, a balloon section, multi-jump towers, ambushes, a charge meter with a Space blast, falling into holes then respawning.

## Process
- Use cheap agents (Haiku first, Sonnet only if needed, never Opus).
- Don't push or deploy without the owner. Work happens on a branch; the owner commits/merges via GitHub Desktop.
