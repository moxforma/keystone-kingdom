# AUDIT3-D: subjects together, accounts, home, menus, save, landing (Haiku auditor, saved by lead)

Tests 65/65. Screenshots: scratchpad/audit3/D-*.png

1. MAJOR. Keylori collide across subjects: S.cards keyed by lesson index `i-f` shared by all streams. Math lesson 1 catches Spinnet; Spell lesson 1 then shows the same card "you're back". Only 117 creatures x 3 forms for all subjects. OWNER DECISION.
2. MAJOR. Math/Spell show the TYPING world-1 story ("Find your fingers... Home Row"). Typing-first players never see a Math/Spell intro. Fix: per-subject intro or skip.
3. MAJOR (by design, typing-only placement test): "Can you type already? Take a test" only on Typing home. Menus otherwise identical.
4. MAJOR (kid text). Typing words in Math/Spell: map/topbar "Home Row Meadow", "Lesson 8: Home Row Meadow Review"; Math results tip "Keep your eyes on the screen, not your hands!".
5. MINOR.
   - Tiles show before a name (intended now).
   - Teachers > Progress report blurb "Speed, accuracy and tricky keys" (typing wording).
   - Phone notice "teaches typing...".
   - Landing nav "SPELLING" vs "SPELL"; nav strip at 390px cuts "MULTIPLAYER"/hides "FOR CLASSROOMS".

Passes: players/switching/reload, combined stars sum, per-subject rows, shared XP/egg/Keystone/daily goal, menu buttons per subject, Esc/Space consistent, savemerge client==server incl. hi lists, landing anchors, no scroll on home at 3 sizes.
Not verified: class dashboard (needs Netlify functions), Math/Spell Boss Test to results, region badges per stream.
