# AUDIT1: Math and Spelling streams vs KEYLORIA_DECISIONS.md

Tested at http://localhost:8769/play/ with Playwright (screenshots in scratchpad audit1/). No page errors.

## Critical
1. **Math Boss Tests never reach the runner boss.** Decision: a Boss Test ends as a runner boss battle. math.js:315 sets `P.phase='end'` before `K.finishClassic`, and runner-lesson.js:338 (`KKS.hybridDone`) needs `P.phase==='play'`, so the chase is skipped. Evidence: bot-mboss1-c-end.png (straight to results). Fix: set `P.phase='play'` before the finish call, as spell-adv.js:168 does.

## Major
2. **Spelling chase: SPACE does nothing.** Decision: SPACE is continue. The modal says "CHASE! (SPACE)", but streams.js:199 sends every key to `P.onKey` during play, so Space never reaches the modal. Clicking works. Evidence: chase-spell-w1-0modal.png. Fix: let an open modal take the key first.
3. **Runner mechanics missing in Math and Spelling.** Decision: forks, balloon section, ambushes, towers, charge blast and holes. Math turns forks and balloons into rocks (runner-math.js:162-163) and clears ambushes (:186). Spelling does the same (runner-spell.js:65-70, :77). Fix: port SEG.fork, SEG.flap and the ambush planner from runner-paths.js and runner-action.js.

## Minor
4. Math boss prompt "Press 17 =" (math-k1.js:45) is confusing. Use "Type 17". Evidence: math-boss-w1-1play.png.
5. Math and Spelling homes still show "Can you type already? Take a test" and a "SPELLING" button (02, 05 screenshots). Hide or relabel.
6. Spelling HEAR uses Space to replay (spell-adv.js:126) and labels the button "TAB" (spell-adv.js:70). Decision: Space is continue. Keep Space free and label the button with a picture.
7. LOOK/HEAR is set per part (spell-adv.js:48), not per world. World 1 always shows the word. Confirm this is intended.
8. Spelling title renders the hyphen as a stray glyph ("¬tion"; spell-classic-w6p1-1play.png). Breaks the pixel look.
9. Runner start modal is four lines of text (math-runner-world9.png). Trim it.

## Passed
- Subject switch on home and Lesson Quests map. Eight parts, runners at 2, 4, 6, 8 (03-map-math.png).
- Classic results show stars, Keylori befriended, "Right 17/17", and no WPM (bot-mw1-c-end.png). Runner results hide WPM for streams (runner-lesson.js:133, code only).
- SPACE continues from classic results in both streams.
- Runner themes match the world (W1, W3, W6, W9, W12). Speed scales by world (math 54 to 84, spelling 56 to 99).
- Falls show "WHOOPS" and respawn. No lives.
- Keyloria Run is not in the Arcade. The mobile notice is kept (11-mobile.png).
- Not checked in depth: typing regressions, the W9 spelling Bee boss, Ontario content.
