# AUDIT2: Keyloria content (math and spelling)

Method: content loaded in a vm; MATH.validate() and SPELLD.validate({complete:true}) pass with 0 errors. Sampled parts 0 and 7 of every math topic and 15 words plus 3 sentences per spelling topic. Hand-checked sampled answers: none wrong. Scripts: /tmp/claude-0/-home-claude/7751b136-1df6-52ba-a765-d25a3a94f902/scratchpad/audit2/run.mjs (plus checks, spstats and aidcheck .mjs).

## Critical
- m4.6 p7 (also m5.5, m11.5): money answer unit switches per item, and the checker takes only the typed form. "Cost $1.55. Pay $2.00. Change?" accepts 45, rejects 0.45. Fix: MATH.check accepts cents and dollars.

## Major
- Pennies (decisions: no pennies): s1.7, s3.3, s4.7, s5.2, s6.3, plus sentences s5.2, s12.1. Fix: nickel, dime or loonie.
- s5.7 "tyre": Canadian is "tire". s12.6 "license" (noun): Canadian is "licence".
- m6.7 p7 "Start 14, add 3. Number 6?" is unclear. Fix: "What is the 6th number?"
- Variety: m3.3 p0 is only dime and nickel; m4.5 p0 only 1/2 and 1/4; m12.5 p0 repeats squares. Fix: mix items.
- Metric: s3.1 "We walked one mile to school." s10.2 "convert centimetres to inches." Fix: kilometre, metre.
- Repeats: Canadian words (honour, colour, centre, metre, travelled) recur in 5-7 topics; s10.7 repeats about 10 words from s9.6. Fix: each word in one topic.
- Gaps: no possessive apostrophes (dog's, girls') in spelling; no symmetry, transformations or position words in math.
- W12 p0 is too easy: m12.1 "2 × 6 + 6", m12.2 "6 + 3", m12.4 "x − 12 = 5". Fix: start at Gr6 level.

## Minor
- m1.1 p0 has only answers 1-3. m1.2 uses "eighteen" in the JK band.
- m3.4 "How many more Tennis?" is unclear. m3.5 "Cube + pyramid: edges?" is beyond Gr1.
- m7.3 "1/2 of a pizza, then 2/3 more" totals 7/6 pizzas.
- Exchange rates differ: m10.7 (0.5, 0.8), m12.7 (0.75).
- m8.4 "Hoodie $565" is unrealistic.
- "Maths" in m11.1 and s12.3 titles: use "Math". m9.7 "Tri. prism": spell out.
- s3.7 lowercase "i'm", "i'd", "i'll". s5.1 "giggle" has a hard g.
- Pattern misfiles: s4.2 after, never; s3.4 skating; s5.3 distance, pretend, reflect; s5.6 ladies; s7.4 sentence; s9.1 irrigate; s11.5 axe; s12.1 road/rode.

## Summary
- Math: 84 topics; 79,553 distinct problems. Lowest: m1.1 (21), m3.3 (88).
- Spelling: 84 topics; 4,479 entries; 3,149 unique words; 2,078 sentences.
- No scary or unsafe content found. Sampled questions are under 50 characters.
