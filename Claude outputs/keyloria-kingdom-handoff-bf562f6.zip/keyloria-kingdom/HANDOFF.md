# Keyloria Kingdom: hand-off (Nov 7, 2026, late)

Read this first, then KEYLORIA_DECISIONS.md (the owner's binding rules). The other docs are reference.

## Where things stand
- **Live site:** keyloria.online (marketing page), with the game at /play. Netlify project "keystone-kingdom" deploys `main` from GitHub `moxforma/keystone-kingdom`. `main` is at 9003e1f (Typing only).
- **New work** is on branch **`stream`** (pull request #2; PR #1 is a duplicate to close).
  - Preview: https://deploy-preview-2--keystone-kingdom.netlify.app/play/
  - GitHub's `stream` is at 9849bd4. On 9849bd4, the `Claude outputs/HEAD` and `Claude outputs/streams` files are junk; delete them.
  - The latest fixes (about 36 files, including the HEAR button, the natural voice and one-line equations) were written into the owner's local repo `E:\Downloads\keystone-kingdom-repo` on `stream`, but were **not yet committed or pushed** when this ZIP was made.
  - **This ZIP is the newest code.** If the owner's `stream` branch is behind, copy these files over it.
- **Owner's workflow:** the owner commits, pushes and merges in GitHub Desktop. Never push to `main` or deploy without him. Do new work on a branch.
- **Agents:** Haiku first, Sonnet only if needed, never Opus.

## The game: three equal subjects in one game
Typing, **Math** and **Spelling** share heroes, Keylori, save file, diamonds/XP, outfits, badges, worlds, runner and bosses.
- **Home:**
  - Three equal subject tiles (TYPE / MATH / SPELL). Each shows the next lesson, its stars and its world. Keys 1/2/3 or the arrows pick a subject; Space starts it.
  - One combined profile card: total stars, plus per-subject rows.
  - The menu is identical in every subject. Arcade, Practice and High Scores open the version for the chosen subject. The "Can you type already? Take a test" link appears only on Typing.
- **Content (Ontario curriculum, JK to Grade 8):**
  - World to grade: W1 = JK/SK, W2-3 = Gr 1, W4 = Gr 2, rising one grade per world to W10 = Gr 8. W11 reviews K-4 and W12 reviews 5-8.
  - Canadian spelling, Canadian money (no pennies), metric.
  - Math: 84 topics, about 79,500 problems. Spelling: 84 topics and 4,443 words, each with an example sentence.
- **Math** (`math.js`):
  - The problem shows big on a chalkboard in the arena, with pixel object sprites (apples, canoes, pucks, coins incl. loonie and toonie, and so on), ten frames, clocks, bars and fractions. The strip below shows only the answer slots.
  - A "Watch me" mini-lesson runs before each topic (`math-teach-1/2/3.js`); ? or H replays it.
  - Digits only in W1. Hints match the question.
  - Equations never wrap: non-breaking spaces go around the operators, and the font shrinks to fit on one line. Word problems wrap only between words. A board with no picture has its text centred.
- **Spelling** (`spell-adv.js`):
  - The word flashes, then is covered:
    - World 1: stays visible.
    - Worlds 2-3: 2.0 s + 0.15 s per letter.
    - Worlds 4-7: 1.2 s + 0.1 s per letter.
    - Worlds 8-12: 0.8 s + 0.08 s per letter.
  - **There is always a visual for anything spoken:** a clue row with a speaker icon, a TAB chip and the sentence with the word blanked.
  - Speech follows the **master sound setting** `S.set.sound`. It does NOT follow `S.set.voice`, which is the optional narration setting and defaults to off.
  - Every word is spoken as word, then sentence, then word. In LOOK parts the cover waits for the first saying (capped at about 4 s).
  - A **big HEAR button** sits in the arena (in classic parts, the Bee boss and spelling runners). Tab, Enter or a click replays the audio, free and unlimited, and it speaks even with sound off. Re-showing the word moved to a small SEE button or Shift+Tab (hidden in W1).
  - Voice choice (`voice.js`), in priority order: "Natural"/"Neural"/"Online" voices (en-CA preferred), then Google UK English Female, Google US English, Samantha and similar, then any en voice. Robotic voices are filtered out. Rate is about 0.8-0.85 and pitch 1.0.
  - Quality depends on the browser's voices (Edge on Windows is best). Pre-recorded human audio would be a future upgrade.
  - Key and finger hints only show for a letter the child just missed. After 2 misses the game shows "Here it is!". Tab re-shows the word once.
- **Runners and bosses** (`runner-math.js`, `runner-spell.js`):
  - Every obstacle shows its problem or word, never a bare "?". This includes the strip under the canvas and the Boss Test chase.
  - Results tips are specific to each subject.
- **Practice and High Scores** (`practice-streams.js`, `KKS_EXTRA.practice/hiscores/addScore/scores`):
  - Practice: a world and topic picker plus Mix, and "My tricky words" for spelling. Practice gives XP but no stars. All 12 worlds are open; the owner chose this.
  - Scores live in `S.streams[id].hi`, which is merged in the save sync.
- **Arcade** (`arcade-streams.js`, `KKS_EXTRA.arcade`):
  - Math: Meteor, Bubble, Dig, Keeper. Spelling: Meteor, Bubble, Dig.
  - Any route to the arcade while in Math or Spelling opens that subject's arcade.
  - No WPM in Math or Spelling arcade results.
  - Typing arcade lives and game-over stay as they are (owner OK'd).
- **Keylori:** one shared collection. Math lessons give the creature in slot (i+39)%117 and Spelling (i+78)%117 (the creature mapping in `streams.js`), so each subject gives different creatures.
- **Intros:** Math and Spelling each have their own World-1 intro and boss taunts. In Math and Spelling, World 1 is called "Keyloria Meadow".
- **"Crystal Caves"** (REGIONS[1]) is folded into World 1 at the end of `streams.js`. Its lessons are kept (they teach the top-row keys E, I, R, U, T, Y) and lesson indexes are unchanged, so saves are safe. It has no separate header, and its titles read "Top Row …".
- **Grown-ups and classroom:**
  - Progress is shown per subject.
  - The class dashboard has a Typing/Math/Spelling toggle.
  - Assignments carry a stream.
  - The class and friend leaderboards are still typing-only (server-side, ranked by WPM).
- **Landing page:** Type · Math · Spell are equal pillars, labelled "mapped to the Ontario curriculum, not officially endorsed".
- **Save format:**
  - Each stream's progress lives in `S.streams[id]`: best, skip, btp, mast, runf, a seen map, story flags in `sv`, and the `hi` score list.
  - `S.stream` holds the current stream.
  - `mergeSave` lives in both `public/savemerge.js` and `netlify/functions/keystone-sync.mjs`. **Keep the two identical.**

## Architecture: key contracts
- **`streams.js`** provides:
  - `KKS.register({...})`.
  - `KKS.slot(i)`, which returns `{w,k,kind,n,g,i}`.
  - `enter/leave/set/cur/startClassic/finishClassic/hybridDone/rec/rl`.
  - All streams share one lesson index space ("view-swap"). Lesson index = save key, so **never reorder or remove LESSONS entries.**
- **`math-data.js`** (`MATH.add/problems/forRunner/check/validate`), with content in `math-k1`, `g23`, `g45`, `g68` and `mix`.
- **`spell-data.js`** (`SPELLD.add/lesson/words/forRunner/validate/checkCanadian`), with content in `spell-w1` through `spell-w10-12`.
- **Runner hooks:** `RUNNER_MATH`/`RUNNER_SPELL` = `{cfg, bossCfg}`. `RUNNER.bossContent` is used by math. `runner-spell.js` wraps `RUNNER.boss`.
- More detail is in STREAMS_PLAN.md.

## Testing
- **Unit tests:** `node --test tests/*.test.mjs` should report 71/71 passing.
- **Browser:** serve `public/` (`python3 -m http.server 8767`) and open `/play/`. Use Playwright for bot play-throughs.
- **Audits:** AUDIT3-A to D are the latest (typing regression, math, spelling, cross-subject). All MAJOR findings are fixed. A final smoke check passed Typing, Math and Spelling lessons, runners and Boss Tests, plus the home screen, menus and arcade.

## Open items and ideas
1. The landing page's animated demo still shows only typing; it could cycle through a math problem and a spelling word.
2. After a wrong answer in Math there is a 1-2 s input pause with no feedback (possibly intended).
3. The home "daily visitor" Keylori can differ between the Type and Math tabs (harmless).
4. Possibly above-grade math items to confirm: W6 mean and mixed numbers, W7 unlike-denominator sums and median.
5. Spelling arcade Meteor and Dig balloon/ambush runner sections show gapped words but no whole-word flash.
7. At 1366x768 the spelling runner's taller clue row pushes the bottom of the on-screen keyboard slightly below the fold.
8. In classic spelling, the covered-word blanks in the strip are small and dim; they could be bigger.
6. Class and friend leaderboards are typing-only.

## Files in this ZIP
The full repo at the newest state, without `.git`, `node_modules`, `.netlify`, the "Claude outputs" folder or any keys. The only secret-looking strings are dummy test fixtures. Also included:
- KEYLORIA_DECISIONS.md: binding owner rules.
- STREAMS_PLAN.md: the architecture plan.
- STREAMS_PROGRESS.md: the build log.
- AUDIT*.md: the audit reports.
