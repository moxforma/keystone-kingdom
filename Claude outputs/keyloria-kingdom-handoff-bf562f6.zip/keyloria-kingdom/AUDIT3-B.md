# AUDIT3-B: MATH stream (auditor B)

Scope: math lessons (W1-12), "Watch me" mini-lessons, the big problem board and aids, runner parts, Boss Tests, Math Practice, Math High Scores, Math Arcade, and a content check of public/math-data.js and the math-*.js content files.
Scripts and screenshots: /tmp/claude-0/-home-claude/7751b136-1df6-52ba-a765-d25a3a94f902/scratchpad/audit3/ (prefix B-).
Lesson index in these notes = the LESSONS index used by KKS.slot(i). startStage(i*8+part). Part 0 is classic (UI part 1), parts 1,3,5,7 are runners (UI parts 2,4,6,8), per the decisions file. Tests used real key presses via Playwright.

## Findings (most severe first)

1. MAJOR (confirmed in game). Every W11 money problem carries the hint "Type 35 or 0.35 for 35¢". After about 9 s idle the speech bubble shows it. Verified on "10¢ + 25¢ + 5¢. Total?" (answer 40).
   Repro: Math, W11 money topic m11.5 (LESSONS index 76), part 0. Wait 10 s without typing.
   Source: public/math-mix.js:144 (x.hint hard-coded). Shown by the idle timer in public/math.js (classic, about line 317).
   Fix: remove the hard-coded hint or write one per answer.

2. MAJOR (confirmed in code and generator output). Hints are picked at random and do not match the question. The idle timer shows them.
   Examples: "90% of 100" or "8/50 = _%" can get "Halve it, halve again". "20.5 × 10³" can get "Which number times itself?" or "List the factors". "Rectangle 5 cm by 7 cm. Perimeter?" and "Pyramid faces?" can get "Count the jumps". "15:00 = _ p.m." can get "Draw it".
   Source: public/math-mix.js:180 (measures), :287 (percent), :350 (powers and factors), :405 (rates). Fix: write the hint with each problem.

3. MAJOR (confirmed). JK/SK world uses number words. Word forms reach kids who cannot read them: "Find four", "Find six = _", "ten = _".
   Repro: Math W1 m1.2 (LESSONS index 1). Words start at generator s=3 (runner part, UI part 4) and s=4 (classic, UI part 5). Also in Arcade Meteor Zap W1, where the rock pool includes these items (screenshot B-arc-meteor-mid.png).
   Source: public/math-k1.js:45-50 (m1.2 gen), and MATH.forRunner rock range rngs [0,3] in public/math-data.js.
   Expected: digits only in W1 (decisions: minimal text; Ontario JK/SK recognises numerals).

4. MAJOR (confirmed, screenshot). The Math Arcade picker card art for Bubble Pop shows typing letters (A, F, J, R bubbles). The Keylori Keeper card sign reads "A —". Kids will expect numbers.
   Screenshot: B-p1366-arcade-picker.png. Source: public/arcart.js ART.bubble (typing art reused for the math card). Fix: number-bubble art for math.

5. MINOR (confirmed). Typing-only copy on Math results.
   - W1 classic result tip: "Sit up tall and relax your shoulders!"
   - W12 runner result tip: "Press the letter just before you reach it!"
   - Passed Math rounds show "No-peek bonus +1 diamond (you typed with the keyboard letters hidden)". Math digits are never hidden. The bonus is awarded on every passed round (public/game.js:1878, public/results2.js:23).
   Fix: stream-specific tips and banner text.

6. MINOR (confirmed in content). Unclear questions for kids.
   - "Mia is 2nd in line. Place behind?" answers 3 (public/math-k1.js:436). Better: "Who is behind Mia?" with a place-number answer.
   - "Most votes?" answers the vote count, not the item (math-k1.js:411).
   - Tally prompts "Votes: 1 more?", "Stars: 1 less?", "Canoes: to 10?" (m1.7) are cryptic for JK/SK.
   - "Pay $?" (m8.4, m12.7) is terse.

7. MINOR, UNCERTAIN (curriculum level, check against Ontario 2020). Some items sit above the world's grade.
   - W6 (Gr 4): "Mean: 3, 30, 17, 10" (math-g45.js:247) and "25/6 as mixed" (Gr 6 style).
   - W7 (Gr 5): unlike-denominator sums "1/2 + 1/6", "3/4 + 1/3" (Gr 6 in my recollection), "Median" (math-g45.js:487), quadrilateral angle sum.
   Owner to confirm.

8. MINOR (confirmed, picture). Coin pictures for toonie and loonie show only a "$" with no value (public/math.js coinsAid). The 5¢ and 10¢ labels are tiny at small board sizes. Screenshot: B-aids.png.

9. MINOR (confirmed, picture). In "1 + _ = 3" gem pictures (W2 m2.6), the blank is a tiny grey tick between groups, hard for kids to see. Screenshot: B-w2k4-p00.png (board is otherwise clear at 1100x800).

10. MINOR (confirmed). Runner feedback "NICE!" is clipped at the left edge of the track in W12. Screenshot: B-W12-p1-tall.png.

11. MINOR, UNCERTAIN. Math Practice lists all 12 worlds as selectable from a W1 save ("Mix" says "World 1"). public/practice-streams.js gridHTML does not lock them. Intent unknown. Screenshot: B-p1366-prac-picker.png.

12. MINOR. Some Watch-me examples are rare in their topic. m4.7 teaches equilateral-triangle symmetry (5 of 480 generated questions). m8.1 teaches GCF (about 4%). Not wrong, but a kid may never see the same skill.

13. UNVERIFIED. Keylori Keeper (W1): foods read "Type 18 =" and "Type 13 =", and a pattern "82828_" sits beside "I want an ODD answer!" It is unclear which food to feed. Screenshot: B-arc-keeper-mid.png. Not confirmed from code.

14. NOT VERIFIED. Arcade end screens (Meteor, Bubble, Dig, Keeper). Random-key bots ran 45 s each: no page errors, no end modal reached. Not finished.

## Checked and OK
- Content (node, vm-loaded math-data.js, math-k1/g23/g45/g68/mix, math-teach-1/2/3):
  - MATH.validate({seeds:120}) ok, 84 topics, 0 errors, 0 warnings. Every generated answer verified by the validator's arithmetic check, with no unverified problems.
  - 17,593 distinct sampled problems (worlds 1-12, lessons 0-8, parts 0-7, 2 seeds): all accepted by MATH.check. Hand-checked about 300 sample lines across all worlds: all correct.
  - Money answers accept plain cents, decimal dollars, and the cent sign. No pennies in prices. Rounding to nearest 5¢ (W5) is an intended exercise.
  - Metric units, Canadian spelling (validator), HST 13% (W9, W12), Canadian money.
  - Pictures match the answers: dots, ten blocks, tally, fraction shading, clock, grid, shapes, and bars.
- Watch me: all 84 mini-lessons' arithmetic checked and correct. Shown once per topic, replayed by H or the ? button (tested: W4 topic m4.1, H and ? button both replay; problem unchanged).
- Classic play to results: W1 part 1 (wrong answers, 2-miss reveal "It is 3", requeued similar problem), W1 part 3, W2 m2.6 (equal and missing, picture equations) and W5 m5.3 (times tables). Each reached the results screen. No page or console errors. Not played: W3, W6-W10 and W11-W12 classic parts (only sampled for content).
- Board: question text on top, picture below or beside. Readable at 1100x800 and 1366x768. Current problem is always visible in the arena and in the strip (no bare "?" in runners, which filter pure text).
- Runners to results: W1 part 2, W4 part 2, W8 part 2, W12 part 2 (all reached the results screen; W12 and W8 needed a bot fix for forks and flaps, which were bot limits, not game bugs).
- Boss Tests to results: W1, W4, W8, W12 (all reached the results screen; W1, W4 and W8 show "Boss Test beaten!").
- Math Practice: picker opens; Mix round starts with a math problem; one Esc shows "Press Esc again to leave" (public/a11y.js double-Esc guard), second Esc goes home.
- Math High Scores screen opens.
- Math Arcade picker opens with Meteor, Bubble, Dig, Keeper. Each game starts with no page errors.

## Verdict
No blockers found in the math stream. The lesson pipeline, checker, runner and boss flows all reached their end screens, and the content is mathematically correct in every sample I could check. The problems that matter for kids are content and copy: the wrong money hint (finding 1), random hints (2), number words in the JK/SK world (3), and the typing-art arcade card (4). Each is a small, targeted fix in math-mix.js, math-k1.js, arcart.js and the results copy. Findings 7 and 13 need an owner decision or a closer look.
