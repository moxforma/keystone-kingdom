# AUDIT3-A (Haiku auditor report, saved by lead)

AUDIT3-A (TYPING regression after Math/Spelling work). Tested in Playwright at 1366x768 against http://localhost:8765/play/ (a server on 8765 was already up; I did not start one). I wrote no report file under /home/claude/kk2, because the system rules bar report .md files and the auditbase asked for one. This report is the deliverable. Screenshots and scripts are in /tmp/claude-0/-home-claude/7751b136-1df6-52ba-a765-d25a3a94f902/scratchpad/audit3/ (files prefixed A-). Helper library: .../audit3/A-lib.js.

TOP FINDINGS (most severe first)

1. MAJOR, pre-existing (base file lessons9.js/extras.js, not changed by the streams work): the typing arcade's Keylori Keeper ends the round when a "life" runs out. Observed: "Squirkle got too grumpy!" after about 3 s of bot misses. Meteor Zap (3 shields, "Oh no!" at 0), Bubble Pop (3 hearts) and Scrambler Attack (5 hearts) also have lose-state mechanics. KEYLORIA_DECISIONS.md says "no game over and no lives". Owner decision needed; not caused by this change. Files: extras.js (ACT.keeper, kp life logic ~L113-114), game.js (startMeteor/endMeteor, glitch hearts), extras.js (bubble hearts).

2. MINOR: Space does not confirm the hero picker. On "THIS IS MY HERO!" (ACT.buyHero) Space does nothing, although the auditbase asks for Space-to-continue on every modal. The global Space handler in streams.js and game.js only acts when screen==='play' or a modal has .rbtns .nextbtn/.btn, and the hero modal's button is not wired that way. Steps: New player, type a name, Enter, pick any hero, press Space, nothing. Click works. Screenshot: A-04-hero-juno.png.

3. MINOR: Escape did not close the Feedback modal (it has a BACK button, which does close it). Observed in the menu sweep, 3 Escape presses left it open; cause not verified (possibly focus in the modal's inputs). Screenshot: A-s-feedback.png (not saved as a separate file; see A-sweep.txt).

4. MINOR, pre-existing data: lessons9.js builds a "Crystal Caves" group (region r=1, 9 lessons) that sits between World 1 and World 2 in Lesson Quests. The 12 curriculum worlds (per the decisions) map to REGIONS r=0,5..15. Regions 2,3,4 (Ember Volcano, Sky Castle, Star Lab) have no lessons at all, so they never appear. Not a regression (lessons9.js is unchanged since the base commit). Owner should confirm the extra group is intended.

5. Pre-existing, not a regression: Treasure Dig and Keylori Keeper only pick up "1-2 words" targets, so a kid has no highlighted key hint except the target row. Unverified whether this is intended.

WHAT PASSED (verified)
- New-player flow: name (Enter saves) -> hero picker (click works) -> "How old are you?" with "I'm new! Start at the beginning" -> Home. Home shows TYPE selected, MATH and SPELL tiles, Start Adventure (Keys F & J warm-up), Arcade, Lesson Quests, Practice, High Scores, Keylori Collection, Progress Report, Keystone counter, Hero Closet, Change Hero. Screenshot: A-08-home-new.png. Looked good at 1366x768.
- World 1 intro story: Space advances all 4 slides. Keyboard Camp runs for a new profile. Lesson splash "Press SPACE to start".
- Classic Part 1 (Keys F & J) to results with 2 deliberate wrong keys: "Oops! Find X" feedback, wrong key does not break the lesson, results show "You befriended Fennip!", stars, Space -> NEXT. Screenshot: A-11-w1p1-after.png.
- Classic plus runner plus Boss Test, through to results or completion, with 0 page errors:
  - World 1 part 2 (runner, one wrong key at rock, 3 stars, "You saved Duskit!").
  - World 1 Boss Test (lesson 89 part 8): classic, then runner chase, "Boss Test beaten! Prize +25 diamonds".
  - Sunscorch (region r=8) part 2 runner, 3 stars, after a classic part 1.
  - Coral Coast (region r=7) part 2 runner, 3 stars, after a classic part 1.
  - Cogwork City (region r=11) Boss Test, classic then chase, "Boss Test beaten".
  - Eclipse Throne (region r=15) Boss Test, classic then chase, "Eclipse Throne cleared!"
  Runner segments seen: rock, fork, tall, flap, gap, boss.
- Arcade (typing), 35 s each unless noted: Meteor Zap (typed correctly, no errors); Bubble Pop (no errors, no end in 35 s); Treasure Dig (19 layers, "Great dig! You reached the goal!", no errors); Keylori Keeper (ended in 3 s by the life rule, see finding 1); Race with Keylori (won, "You won the race!", results show 1st, 81 WPM, 85%); Scrambler Attack (glitch, no errors in 35 s, no results reached). All back buttons return to the arcade, and Escape returns to the arcade.
- Math arcade visited first, then typing arcade: Math Arcade opens and shows its 4 games (Meteor, Bubble, Dig, Keeper); switching back to TYPE restores the typing arcade.
- Subject switch check (A-switch.txt): played typing part 1, then switched to MATH (tile click), opened Math hiscores, Math arcade via KKS_EXTRA.arcade.math(), switched to SPELL and back to TYPE. Typing keys S.best, S.hist, S.time, S.rounds, S.ks and S.arc were identical before and after (hist length 1, best {"0-0":3}, time 1, rounds 1). S.streams.math was created but empty. So switching subjects does not change typing progress or WPM. PASS.
- Home-screen menus (sweep A-sweep.txt; each opened, Space checked, back checked): Arcade, Lesson Quests (map), Keylori Collection (binder), Hero Closet (shop), Practice (modal: Sentences and Paragraphs locked until Lesson 14; Trouble Keys; Letter Combos; Free Write; Close), High Scores (modal), Progress Report (grown-ups screen), Select Player (modal with the player card and + New player), Settings (modal), How to Play (opens a new tab to /), Feedback (grown-ups-only gate, then BACK). Back buttons work on each screen except as in finding 3. Space does not close menu modals (expected, they are menus, not continue prompts).
- Lesson Quests with progress: world sections render with stage buttons; regions as in finding 4.

NOT COVERED (so the verdict has gaps)
- Placement test link ("Can you type already? Take a test") was seen but not clicked.
- Keylori Collection contents, Hero Closet purchases, Keystone/story recap screens were opened but not exercised.
- Story Bridge and Race with Others arcade games not played.
- Viewports 1920x1080 and 1100x800 not tested.
- No visual review of Lesson Quests at scale beyond the first sections.
- Glitch and Bubble arcade: no round end seen in 35 s, so results screens for those two are unverified.

VERDICT: The typing stream still works end to end. Classic lessons, runner parts, Boss Tests, arcade, practice, scores and menus all ran with no page errors, and switching subjects leaves typing progress and WPM untouched. The open items are a rule conflict in the arcade (lives and game over in Keeper, Meteor, Bubble and Scrambler, all pre-existing), a Space gap on the hero picker, and an Escape gap on Feedback. Nothing here is a blocker for the Typing stream.