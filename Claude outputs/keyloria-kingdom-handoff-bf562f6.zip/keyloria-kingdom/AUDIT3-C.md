# AUDIT3-C (Haiku auditor report, saved by lead)

AUDIT LETTER C (spelling stream). Status: PARTIAL. The classic sweep (W3, W6, W10, W12 parts 0/2/4/6) was still running; 10 of 16 parts finished, and W10 parts 4 and 6 and all W12 parts are not yet run. Its timeline JSON is written only when the process ends, so per-part flash-timing numbers for W6-W12 are not in hand. I did NOT write /home/claude/kk2/AUDIT3-C.md because the system rules bar report .md files; this message is the report. Setup: static server on :8767, Playwright, S.set.voice=false, real key presses, 1366x768. Scripts and screenshots are in /tmp/claude-0/-home-claude/7751b136-1df6-52ba-a765-d25a3a94f902/scratchpad/audit3/ (C-*.js) and .../audit3/C/.

FINDINGS, most severe first:

1. MAJOR. Spelling HEAR parts ignore the sound setting. spell-adv.js sayParts() calls speechSynthesis directly with no S.set.voice gate (game.js speak() and voice.js do check it). Repro: any LOOK/HEAR lesson, sound off. A stubbed speechSynthesis logged 20 utterances in a W1 LOOK part with voice off. HEAR-part speech is by code path (sayWord->sayParts), not separately counted. Also listenThenFlash waits for onend before flashing the word, with a 9 s fallback, so with sound off the word stays hidden for that wait. Suspect: spell-adv.js sayParts / sayWord / listenThenFlash.

2. MAJOR. The example sentence is spoken (HEAR parts, Bee, Tab re-hear) but never shown on screen. This breaks the owner's "visual for everything spoken" rule. Screenshot/timeline of HEAR phase: only the bubble "Listen!"/"Spell it!" and the covered word; the sentence appears nowhere. Suspect: spell-adv.js sayWord().

3. MAJOR, needs owner decision. Hints reveal more than the letter just missed:
 a. Classic: after 2 misses on a word, "Here it is!" sets R.vis=true and shows the whole word (spell-adv.js gameInput miss branch). Code-verified.
 b. Classic: Tab in W2+ (first press per word) re-flashes the full word; costs accuracy from W4. Code-verified (hearAgain).
 c. Arcade Meteor (spell): after an error on a covered meteor, peekMeteor() removes cov from all letters for 1.3 s, showing the whole word. Code-verified (arcade-streams.js peekMeteor); not seen in a screenshot (my test never caught a covered meteor).
 Owner rule as relayed: hints never reveal a covered word except the letter just missed. Each path above breaks that.

4. MAJOR. Spelling Arcade Meteor results show a WPM figure, and a typing-only "Daily egg warmed up: 1 of 3" card. Verified: the visible card shows "Daily egg warmed up 1 of 3"; WPM "11" is in the modal DOM text under "TAP FOR DETAILS" (not seen visually). Owner: WPM is typing-only. Suspect: arcade results code shared with typing.

5. MAJOR (content). Only 1,648 of 3,234 distinct spelling words have any example sentence (51%). Per world: W1 41%, W2 23%, W3 28%, W4 38%, W5 64%, W6 37%, W7 46%, W8 61%, W9 91%, W10 45%, W11 50%, W12 61%. For the rest, HEAR parts speak the bare word. HANDOFF's "2,122 sentences" is accurate but does not disclose this gap.

6. MINOR. Mixed -ise/-ize: analyse, practise, advertise, and others vs synchronize, criticize, summarize. Canadian convention is usually -ize; owner to decide.

7. MINOR. Treasure Dig (spell) timed out with a score of 0, and that 0 was saved to S.streams.spell.hi.dig. Bot did not pick words, so dig gameplay itself is untested.

8. MINOR. Spelling lesson header shows the typing region name "Home Row Meadow" for W1 lessons (seen in screenshot).

9. MINOR. Spelling Practice picker lists all 12 worlds, even those beyond the player's progress; no lock is applied (observed). Owner design question.

10. MINOR. W6 runner results modal contains raw CSS text (".spex{display:grid...}") in its DOM text, from runner.js ~line 166. Not visible in the screenshot I checked.

11. MINOR. Arcade Bubble (spell) falls back to a hard-coded W1 word list (cat, dog, sun...) when fewer than 8 words are found (arcade-streams.js spellItems). Code-verified, not triggered.

12. MINOR. W1 runner (part 2): the "_uck" label is partly hidden behind a platform. One screenshot (run-w1p2-cover-fork.png).

PASSING (verified):
- SPELLD.validate({complete:true}): ok, 84 topics, 4,443 words, 2,122 sentences, 0 errors.
- checkCanadian: no US forms in words or sentences (colour, centre, neighbour, travelled, cheque, licence noun, practise verb, all correct).
- Every sentence contains its word (stem match): 0 misses.
- No duplicate word in a lesson; no identical sentence reused within a lesson.
- Simulated 20,160 rounds from SPELLD.words: no duplicate word in a round, none short.
- Sentence sampling (about 3 per topic) reads sensibly for grade; no inappropriate words (only "hymn", "vein", "blood" in science context).
- Flash timing matches spec in code (flashMs: W2-3 2.0 s + 0.15/letter; W4-7 1.2 + 0.1; W8-12 0.8 + 0.08; W1 stays visible). The W1 timeline confirmed the word stays visible.
- Key/finger hint hidden while covered; after a miss it shows only the letter just missed (screenshot w3-i16-s0-miss.png shows the 'i' hint and the covered word).
- Runner parts to results with 0 page errors (bot, sound off): W1 parts 2,4,6,8; W3 parts 2,4,6,8; W6 parts 2,4,6,8; W10 parts 2,4,8. W10 part 6 timed out at the bot's 170 s limit while still progressing; inconclusive, not a stuck game.
- Boss chase to results (RUNNER.open bot, sound off): W1, W3, W6, W10 all reached results.
- W3 Boss Test via the real path: classic Bee part (typed) reached "Rumbletusk runs away! Chase it!", then the runner screen. My bot did not play the chase itself, so the full classic-to-chase-to-results path is not verified end to end in one run.
- Runner visuals checked in screenshots: rocks (srock), bridges with covered words and plank slots, towers, forks, flap words. Nothing blank; each obstacle showed a visible prompt.
- Practice: picker, W2 topics, Mix (title "Practice", sub "Mix"), My tricky words correctly disabled ("None yet"), hi-score tabs (Meteor Zap, Bubble Pop, Treasure Dig, Best lessons), arcade picker (Meteor/Bubble/Dig). No page errors.
- Arcade Bubble (spell) ran to the end, 946 points, no errors.
- Classic LOOK/HEAR parts completed to the "befriended" results card in W1, W3 (parts 0,2,4,6), W6 (parts 0,2,4,6), W10 part 0 and 2, with 0 page errors.

NOT VERIFIED: Bee boss classic on W6, W10, W12 (sweep incomplete); W12 classic entirely; sweep timelines for flash timing in W6-W12; arcade Meteor peek visually.

VERDICT: The spelling stream plays end to end with no page errors and the content validates cleanly, with Canadian spelling and grade-appropriate words. Two rules are broken for the owner's sound-off test: (1) HEAR parts speak even when sound is off, and (2) the spoken sentence has no visual. Hint reveals beyond the missed letter (Here it is!, Tab peek, arcade Meteor peek) need an owner decision. WPM and the typing daily card leak into spelling arcade results. Content covers only half the words with sentences. Recommended top fixes: gate sayParts on S.set.voice and show the sentence on screen; remove WPM and the daily card from the spelling results; decide the reveal rules.

Memory: nothing read or written. No facts here came from memory.