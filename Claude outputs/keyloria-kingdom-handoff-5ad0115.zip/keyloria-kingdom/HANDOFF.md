# Keyloria Kingdom: hand-off (Nov 6, 2026)

Read this first, then KEYLORIA_DECISIONS.md (the owner's binding rules). The other docs are reference material.

## Where things stand
- **Live site:** keyloria.online (marketing page). The game is at /play. Netlify project "keystone-kingdom" deploys from GitHub `moxforma/keystone-kingdom`, branch `main`, which is at commit 9003e1f (Typing only).
- **New work:** branch `stream`, commit 5ad0115 "math and spelling", is open as **pull request #2**. Its deploy preview is https://deploy-preview-2--keystone-kingdom.netlify.app/play/. PR #1 is a duplicate and should be closed. This ZIP's code matches that branch exactly. **Nothing is merged to main yet.**
- **Owner's workflow:** the owner commits and merges through GitHub Desktop (local repo `E:\Downloads\keystone-kingdom-repo`). Never push to `main` or deploy without the owner. Do new work on a branch.
- **Agents:** Haiku first, Sonnet only if needed, never Opus.

## What was built: three learning streams in one game
Typing (existing), **Math** and **Spelling** share heroes, Keylori, save file, diamonds/XP, outfits, badges, worlds, runner and bosses.
- The **subject switch** (TYPE / MATH / SPELL) is on the home and map screens. You can also use the arrow keys, 1-3 or Space. It only shows once a player has a name.
- **Content:** Ontario curriculum, JK to Grade 8.
  - World to grade: W1 = JK/SK, W2-3 = Gr 1, W4 = Gr 2, rising one grade per world to W10 = Gr 8. W11 reviews K-4 and W12 reviews 5-8.
  - Canadian spelling, Canadian money (no pennies), metric units.
  - Math: 84 topics, about 79,500 distinct generated problems.
  - Spelling: 84 topics, 4,443 words, 2,122 example sentences.
- **Math classic mode** (`math.js`):
  - A problem strip that auto-submits when the answer is the right length.
  - Visual aids, finger hints on digits, and the answer is revealed and the problem re-queued after 2 misses.
  - A **"Watch me" mini-lesson** (a chalkboard that solves one example step by step) appears before part 1 of each topic. Its content is in `math-teach-1/2/3.js`. It shows once per topic; "?" or H replays it.
- **Spelling classic mode** (`spell-adv.js`):
  - LOOK and HEAR parts alternate, and the lesson ends with a mini "Bee" boss.
  - The word is **shown briefly, then covered**:
    - World 1: stays visible.
    - Worlds 2-3: 2.0 s + 0.15 s per letter.
    - Worlds 4-7: 1.2 s + 0.1 s per letter.
    - Worlds 8-12: 0.8 s + 0.08 s per letter.
  - Key and finger hints are hidden while the word is covered and come back only for a letter the child just missed.
  - Tab (or the speaker) re-shows the word once.
- **Runners and bosses:**
  - `runner-math.js` and `runner-spell.js` plug into the Keyloria Run engine. Rocks, bridges and towers become problems or words. They keep forks, flap sections and ambushes.
  - Boss Tests start in classic mode and end in a runner chase.
- **Grown-ups and classroom:**
  - Progress is shown per subject.
  - The class dashboard has a Typing/Math/Spelling toggle.
  - Assignments carry a stream.
  - Focus-mode switches cover math and spell.
  - The landing page has Math and Spelling sections, described as mapped to the Ontario curriculum, not officially endorsed.
- **Save format:**
  - Each stream's progress lives in `S.streams[id]` (best, skip, btp, mast, runf, plus a "seen" map for lessons).
  - Shared items stay top-level.
  - `S.stream` holds the current stream.
  - `mergeSave` is mirrored in `public/savemerge.js` and `netlify/functions/keystone-sync.mjs`. **Keep the two identical.**

## Architecture: key contracts
- **streams.js** sets up `KKS.register({id,name,kbd,regionDesc[12],topicFor(w,slot,kind),title?,classic(n),runnerCfg(i,s)|null,bossCfg(i)|null})`. It also provides `KKS.slot(i)`, which returns `{w,k,kind,n,g,i}` (k values: 0-6 learn, 7 review, 8 boss), plus `enter/leave/set/cur/startClassic/finishClassic/hybridDone/rec/rl`. All streams share the same lesson index space ("view-swap").
- **math-data.js** (`MATH`): `MATH.add({id:'m3.2',world,n,strand,exp,title,ans,gen(rng,s,tier)->{q,a,aid?,hint?}})`. It also provides `problems`, `forRunner`, `check`, `validate`. Content lives in `math-k1.js`, `math-g23.js`, `math-g45.js`, `math-g68.js` and `math-mix.js`. Mini-lessons are `window.MATH_TEACH[topicId]={ex,a,steps[2-5],tip?}`.
- **spell-data.js** (`SPELLD`): `SPELLD.add({id:'s<w>.<n>',world,n,grade,title,pattern,exp,words:'a|b@g',sents:{word:'Sentence.'}})`. It also provides `lesson`, `words`, `forRunner` (which skips apostrophe and hyphen words), `validate`, `checkCanadian`. Content lives in `spell-w1.js` through `spell-w10-12.js`.
- **Runner hooks** (`runner.js`, `runner-paths.js`, `runner-action.js`, `runner-boss.js`):
  - The math and spell plug-ins are `window.RUNNER_MATH` and `window.RUNNER_SPELL`, each `{cfg(i,s), bossCfg(i)}`.
  - `RUNNER.bossContent` is set for math only.
  - `runner-spell.js` wraps `RUNNER.boss` as a dispatcher.
- More detail is in STREAMS_PLAN.md, especially section 9 (the content plan).

## Testing
- **Unit tests:** `node --test tests/*.test.mjs` should report 64/64 passing.
- **Browser:** serve `public/` locally (`python3 -m http.server 8765`) and open `/play/`. Playwright works for bot play-throughs. Typing must still play through on normal and hard runner levels with no page errors.
- **Not yet verified end to end:** a Spelling Boss Test right through to the final results screen, and the runner's help-after-a-miss for covered spelling letters.

## Open items (the owner's latest question and the next jobs)
1. **The menus differ between streams.** Typing shows two buttons that Math and Spell hide: the old **SPELLING** button (`spelling.js`, now redundant with the SPELL tab) and the **"Can you type already? Take a test"** link. This makes the home buttons reflow. The plan proposed to the owner (waiting for his answer):
   - Remove the old SPELLING button from Typing as well.
   - Either add per-stream placement tests or hide the test link in all three streams.
2. **Arcade, Practice and High Scores still open the typing versions from Math and Spell** [likely; check before changing]. Proposed: hide them in Math and Spell for now, or build stream versions later.
3. The lesson splash ignores Space for about the first second (minor; the test bots needed a 1.8 s wait).
4. Optional: a Haiku agent smoke test of the spelling Boss Test right through to results.
5. Once the owner approves the preview, he merges PR #2 himself.

## Files in this ZIP
The full repo at the `stream` branch, without `.git`, `node_modules`, `.netlify` or any keys. The only secret-looking strings are dummy fixtures in `tests/`. Also included:
- KEYLORIA_DECISIONS.md: binding owner decisions.
- STREAMS_PLAN.md: the architecture and content plan.
- STREAMS_PROGRESS.md: the build log.
- AUDIT1.md (gameplay) and AUDIT2.md (content): the audit findings, all fixed.
